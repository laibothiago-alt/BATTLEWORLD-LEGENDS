const A='/assets/';
const CHARS={
'FELPHS SILVERHAND':{card:'FELPHS SILVERHAND/file_00000000b770820eaa9ca06cea9bcbd9.jpg',moves:['file_000000000890820ea8f8594f21d68df5.jpg','file_000000001850820ebd9d440f5a49e1ad.jpg','file_0000000057c4820eb5b288e2a415eb61.jpg','file_000000008b8c820e8eebafe957f71215.jpg','file_00000000bb60820e905f302b82675cab.jpg','file_00000000d5c4820e8d57882b0f56fcbb.jpg','file_00000000d5f4820e9424cb1762506825.jpg']},
'JACK BLOOD':{card:'JACK BLOOD/file_000000003934820ea993fa681e0cfdbb.jpg',moves:['file_000000005e64820eb3a477d5539f5d61.jpg','file_0000000061fc820e902a5107a8a84a18.jpg','file_000000008294820eaf545565625699d3.jpg','file_0000000089f8820ea01ac97e5055baae.jpg','file_00000000ac9c820ea059182a2ff374bc.jpg','file_00000000d850820e9fb8ac16af023c22.jpg','file_00000000f54c820e81eeae5b79c33bdd.jpg']},
'MARSHALL B NICKO':{card:'MARSHALL B NICKO/file_000000005c88820eba4861e4445369ed.jpg',moves:['file_000000002f48820e93459efaab93496f.jpg','file_000000005abc820ea6b92521a397d8e7.jpg','file_000000006880820ebb1739bcdda37710.jpg','file_000000007d5c820e84da2630360b1efb.jpg','file_00000000c7ac820eac28dd0237e0e9c9.jpg','file_00000000f428820eb0d90b9289110ced.jpg','file_00000000fc24820ea9077031c3902ad9.jpg']},
'MATH SEVERUS':{card:'MATH SEVERUS/file_000000004450820e895695f2d4fd158e.jpg',moves:['file_0000000038ec820e90ec852b0e7585e6.jpg','file_0000000049d4820ea9cdd7fdd3327ec0.jpg','file_000000004e2c820ebd15ad656f612dfe.jpg','file_000000006fec820eb73b1bead40e091e.jpg','file_000000008a84820ea9031cb96769e9cf.jpg','file_00000000d434820ea875e9bad6660568.jpg','file_00000000e078820e9f96e91d48f6d430.jpg']},
'MUCA BLACKOUT':{card:'MUCA BLACKOUT/file_00000000b51c820eb3f795893bdf791e.jpg',moves:['file_000000000008820eb95bb4cc191cd041.jpg','file_000000000fc8820eba2bd6af5f86e103.jpg','file_000000002f34820e9d2771435e24ba2c.jpg','file_000000005014820eaa85782b830b9abd.jpg','file_00000000aad4820e9f44e28dfcbccc1b.jpg','file_00000000e52c820ebd68f513879d0c0b.jpg','file_00000000f2b0820e9904eaa3540afce2.jpg']},
'O PATRIOTA':{card:'O PATRIOTA/file_00000000123c820eb7d0a6885da819b4.jpg',moves:['file_000000000830820e91e32bf6f577eacb.jpg','file_000000003774820ead9b13366b542808.jpg','file_000000004d78820ea4a6fdd935ec5e3c.jpg','file_000000008dd4820ea27b004fcb32db94.jpg','file_00000000d334820ea5035903751e0428.jpg','file_00000000e590820e8e408c07590e295b.jpg','file_00000000e824820eb4656999f02d03e7.jpg']}
};
const moveMeta=[{attr:'FORÇA',damage:20,cost:1},{attr:'ARCANA',damage:25,cost:1},{attr:'BALÍSTICA',damage:30,cost:1},{attr:'ESTRATÉGIA',damage:35,cost:1},{attr:'FORÇA',damage:40,cost:2,effect:'ATORDOAMENTO'},{attr:'ARCANA',damage:45,cost:2,effect:'SANGRAMENTO'},{attr:'BALÍSTICA',damage:55,cost:3,effect:'QUEIMADURA'}];

const CHAR_DATA={
'FELPHS SILVERHAND':{hp:280,stats:{'FORÇA':0,ARCANA:0,'BALÍSTICA':20,'ESTRATÉGIA':20},resources:{'MUNIÇÃO':6}},
'JACK BLOOD':{hp:200,stats:{'FORÇA':25,ARCANA:0,'BALÍSTICA':0,'ESTRATÉGIA':20},resources:{LETALIDADE:6}},
'MARSHALL B NICKO':{hp:300,stats:{'FORÇA':20,ARCANA:20,'BALÍSTICA':0,'ESTRATÉGIA':0},resources:{ESTAMINA:6,MANA:6}},
'MATH SEVERUS':{hp:300,stats:{'FORÇA':25,ARCANA:0,'BALÍSTICA':10,'ESTRATÉGIA':0},resources:{ESTAMINA:6,'MUNIÇÃO':6}},
'MUCA BLACKOUT':{hp:300,stats:{'FORÇA':10,ARCANA:10,'BALÍSTICA':20,'ESTRATÉGIA':20},resources:{'MUNIÇÃO':6,'TÁTICA':6}},
'O PATRIOTA':{hp:320,stats:{'FORÇA':25,ARCANA:0,'BALÍSTICA':10,'ESTRATÉGIA':0},resources:{ESTAMINA:6}}
};
const ATTR_BEATS={'FORÇA':'ARCANA',ARCANA:'BALÍSTICA','BALÍSTICA':'ESTRATÉGIA','ESTRATÉGIA':'FORÇA'};

let token=localStorage.bwtoken||'',me=null,selected=Object.keys(CHARS)[0],poller=null,state=null,locked=false,roomId=null,lastEventId=null,offlineMode=false,savedOnlineMe=null;
const $=id=>document.getElementById(id);
function show(id){
  const t=$('transition'); if(t){t.classList.remove('go'); void t.offsetWidth; t.classList.add('go')}
  setTimeout(()=>{document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));$(id).classList.add('active');window.scrollTo(0,0)},150);
}
function openAuth(kind){$('auth').classList.add('show');$('authTitle').textContent=kind==='register'?'CRIAR CONTA':'ENTRAR';$('authBtn').textContent=kind==='register'?'CADASTRAR':'ENTRAR';$('authError').textContent='';$('authBtn').onclick=()=>auth(kind)}function closeAuth(){$('auth').classList.remove('show')}
async function auth(kind){let username=$('username').value.trim(),password=$('password').value;let r=await fetch('/api/'+kind,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})});let d=await r.json();if(!r.ok)return $('authError').textContent=d.error||'Erro';token=d.token;localStorage.bwtoken=token;me=d.user;closeAuth();renderHome()}
async function loadMe(){if(!token)return renderHome();let r=await fetch('/api/me',{headers:{Authorization:'Bearer '+token}});if(!r.ok){token='';localStorage.removeItem('bwtoken');return renderHome()}me=await r.json();renderHome()}
function renderHome(){$('guestPanel').classList.toggle('hidden',!!me);$('userPanel').classList.toggle('hidden',!me);if(me){$('profileName').textContent=me.username;$('profileRank').textContent=`ELO ${me.rating} • ${me.wins}V/${me.losses}D`}}
function logout(){localStorage.removeItem('bwtoken');token='';me=null;renderHome()}
function openRoster(){
 offlineMode=false;
 renderRoster();
 $('rosterModeLabel').textContent='RANQUEADO 1V1';
 $('rosterModeTitle').textContent='ESCOLHA SEU LUTADOR';
 $('rosterStartLabel').textContent='BUSCAR OPONENTE';
 $('myRank').textContent=`${me.username} • ELO ${me.rating}`;
 $('selectedName').textContent=selected;
 show('roster')
}
function openOfflineRoster(){
 if(!offlineMode)savedOnlineMe=me;
 offlineMode=true;
 if(!me)me={username:'VOCÊ',rating:1000,wins:0,losses:0};
 renderRoster();
 $('rosterModeLabel').textContent='MODO OFFLINE';
 $('rosterModeTitle').textContent='ESCOLHA SEU LUTADOR';
 $('rosterStartLabel').textContent='LUTAR CONTRA CPU';
 $('myRank').textContent='OFFLINE • CPU';
 $('selectedName').textContent=selected;
 show('roster')
}
function leaveRoster(){
 if(offlineMode){offlineMode=false;me=savedOnlineMe;savedOnlineMe=null;renderHome()}
 show('home')
}
function startSelectedMode(){return offlineMode?startOfflineBattle():queueRanked()}

function renderRoster(){let g=$('rosterGrid');g.innerHTML='';Object.entries(CHARS).forEach(([n,c])=>{let b=document.createElement('button');b.className='slot'+(n===selected?' sel':'');b.innerHTML=`<img src="${A+c.card}"><span>${n}</span>`;b.onclick=()=>{selected=n;$('selectedName').textContent=n;renderRoster()};g.appendChild(b)})}

function cloneObj(x){return JSON.parse(JSON.stringify(x))}
function makeOfflinePlayer(username,char,rating=1000){
 const c=CHAR_DATA[char];
 return {username,rating,char,hp:c.hp,maxHp:c.hp,stats:cloneObj(c.stats),resources:cloneObj(c.resources),fuga:2,fugaClock:0,effects:[],pick:null}
}
function startOfflineBattle(){
 const enemyChoices=Object.keys(CHARS).filter(n=>n!==selected);
 const enemyChar=enemyChoices[Math.floor(Math.random()*enemyChoices.length)];
 const playerName=me?.username||'VOCÊ';
 state={id:'offline',turn:1,phase:'choosing',locked:false,players:[makeOfflinePlayer(playerName,selected,me?.rating||1000),makeOfflinePlayer('CPU',enemyChar,1000)],lastEvent:null,finished:null};
 roomId='offline';
 clearInterval(poller);poller=null;lastEventId=null;locked=false;
 show('battle');
 $('log').innerHTML=`MODO OFFLINE iniciado.<br>CPU selecionou ${enemyChar}.<br>`;
 $('status').textContent='ESCOLHA UM GOLPE';
 renderBattle()
}
function offlineEffectBonus(m){return m.effect==='SANGRAMENTO'?20:m.effect==='QUEIMADURA'?10:0}
function offlineGain(p,jokempo){if(p.resources.LETALIDADE!==undefined)p.resources.LETALIDADE=Math.min(6,p.resources.LETALIDADE+1);if(jokempo&&p.resources['TÁTICA']!==undefined)p.resources['TÁTICA']=Math.min(6,p.resources['TÁTICA']+2)}
function offlineTickFuga(p){p.fugaClock=(p.fugaClock||0)+1;if(p.fugaClock>=2){p.fuga=Math.min(2,p.fuga+1);p.fugaClock=0}}
function offlineAffordable(p){
 return moveMeta.map((m,i)=>({m,i,res:resourceFor(p,m)})).filter(x=>(p.resources[x.res]||0)>=x.m.cost)
}
async function offlinePick(slot){
 if(locked||state?.finished)return;
 const a=mine(),b=foe(),ma=moveMeta[slot],raRes=resourceFor(a,ma);
 if((a.resources[raRes]||0)<ma.cost){log('⚠ Recurso insuficiente');return}
 const choices=offlineAffordable(b);
 if(!choices.length){log('CPU sem golpe disponível.');return}
 const cpu=choices[Math.floor(Math.random()*choices.length)],mb=cpu.m;
 a.resources[raRes]-=ma.cost;b.resources[cpu.res]-=mb.cost;
 const rollA=1+Math.floor(Math.random()*12),rollB=1+Math.floor(Math.random()*12);
 const bonusA=ATTR_BEATS[ma.attr]===mb.attr?5:0,bonusB=ATTR_BEATS[mb.attr]===ma.attr?5:0;
 const totalA=rollA+bonusA,totalB=rollB+bonusB;
 const dmgA=(a.stats[ma.attr]||0)+ma.damage+offlineEffectBonus(ma),dmgB=(b.stats[mb.attr]||0)+mb.damage+offlineEffectBonus(mb);
 let winner=null;
 if(totalA>totalB){b.hp-=dmgA;winner=a;offlineGain(a,bonusA>0)}
 else if(totalB>totalA){a.hp-=dmgB;winner=b;offlineGain(b,bonusB>0)}
 else {a.hp-=dmgB;b.hp-=dmgA}
 offlineTickFuga(a);offlineTickFuga(b);
 const ev={type:'reveal',id:'off_'+Date.now(),a:{username:a.username,char:a.char,slot,move:ma,roll:rollA,bonus:bonusA,total:totalA,damage:dmgA},b:{username:b.username,char:b.char,slot:cpu.i,move:mb,roll:rollB,bonus:bonusB,total:totalB,damage:dmgB},winner:winner?.username||null};
 state.turn++;
 if(a.hp<=0&&b.hp<=0)state.finished={draw:true};
 else if(a.hp<=0)state.finished={winner:b.username};
 else if(b.hp<=0)state.finished={winner:a.username};
 await animateReveal(ev);
 renderBattle();
 if(state.finished){
   locked=true;
   $('status').textContent=state.finished.draw?'EMPATE!':`${state.finished.winner} VENCEU!`;
   log(state.finished.draw?'🏁 EMPATE!':`🏆 ${state.finished.winner} VENCEU A PARTIDA!`);
 }
}
async function offlineRecover(kind){
 const p=mine(),map={RECARREGAR:['MUNIÇÃO',6],MEDITAR:['MANA',4],'FÔLEGO':['ESTAMINA',3]},v=map[kind];
 if(!v||p.resources[v[0]]===undefined){log('⚠ Ação indisponível');return}
 if(p.resources[v[0]]>=6){log(`⚠ ${v[0]} já está 6/6`);return}
 p.resources[v[0]]=Math.min(6,p.resources[v[0]]+v[1]);pulseHud('me');
 const choices=offlineAffordable(foe());
 if(choices.length){
   const c=choices[Math.floor(Math.random()*choices.length)],enemy=foe();enemy.resources[c.res]-=c.m.cost;
   const dmg=(enemy.stats[c.m.attr]||0)+c.m.damage+offlineEffectBonus(c.m);p.hp-=dmg;
   cinematicFx('ATAQUE!');log(`CPU atacou após ${kind} e causou ${dmg} de dano.`);
 }
 offlineTickFuga(p);offlineTickFuga(foe());state.turn++;renderBattle();
 if(p.hp<=0){state.finished={winner:'CPU'};locked=true;$('status').textContent='CPU VENCEU!'}
}
function offlineFuga(){
 const p=mine();if(p.fuga<=0){log('⚠ FUGA sem cargas');return}
 p.fuga--;cinematicFx('FUGA!');log(`${p.username} usou FUGA (${p.fuga}/2).`);renderBattle()
}

async function showRank(){let r=await fetch('/api/rank'),list=await r.json();$('rankList').innerHTML=list.map((x,i)=>`<div class="rankrow"><b>#${i+1}</b><span>${x.username}</span><b>${x.rating}</b><small>${x.wins}V/${x.losses}D</small></div>`).join('');$('rankModal').classList.add('show')}
async function queueRanked(){if(!token)return openAuth('login');$('queueChar').textContent='LUTADOR: '+selected;show('queue');let d=await api('/api/queue','POST',{char:selected});if(d.matched){roomId=d.room;beginMatch()}else{pollQueue()}}
async function api(url,method='GET',data){let r=await fetch(url,{method,headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:data?JSON.stringify(data):undefined});let d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Erro');return d}
function pollQueue(){clearInterval(poller);poller=setInterval(async()=>{try{let d=await api('/api/queue/status');if(d.matched){clearInterval(poller);roomId=d.room;beginMatch()}}catch{}},700)}
function beginMatch(){show('battle');$('log').innerHTML='Oponente encontrado.<br>';clearInterval(poller);poller=setInterval(loadState,500);loadState()}
async function loadState(){if(!roomId)return;try{let s=await api('/api/state?room='+encodeURIComponent(roomId));state=s;renderBattle();if(s.lastEvent&&s.lastEvent.id!==lastEventId){lastEventId=s.lastEvent.id;handleEvent(s.lastEvent)}if(s.finished){clearInterval(poller);if(s.finished.draw)log('EMPATE!');else log(`🏆 ${s.finished.winner} VENCEU A PARTIDA!`);await loadMe();setTimeout(()=>show('home'),3500)}}catch(e){}}
async function handleEvent(e){if(e.type==='reveal')animateReveal(e);else if(e.type==='freeAttack')animateFreeAttack(e);else if(e.type==='system')log(e.text)}
function mine(){return state?.players.find(p=>p.username===me.username)}function foe(){return state?.players.find(p=>p.username!==me.username)}
function chips(p){
 let icons={MUNIÇÃO:'▰',MANA:'◈',ESTAMINA:'✊',LETALIDADE:'◆',TÁTICA:'▱'};
 let base=Object.entries(p.resources||{}).map(([k,v])=>`<span class="chip">${icons[k]||'◆'} ${k} ${v}/6</span>`).join('');
 let effects=(p.effects||[]).map(e=>`<span class="chip effect">${e}</span>`).join('');
 return base+`<span class="chip">〰 FUGA ${p.fuga}/2</span>`+effects
}
function hud(el,p){el.innerHTML=`<h3>${p.username}</h3><div class="hud-info"><span class="heart">♥</span> VIDA ${Math.max(0,p.hp)}/${p.maxHp} • ELO ${p.rating}</div><div class="bar"><i style="width:${Math.max(0,p.hp/p.maxHp*100)}%"></i></div><div class="chips">${chips(p)}</div>`}
function renderBattle(){if(!state)return;let a=mine(),b=foe();if(!a||!b)return;locked=!!state.locked;hud($('hudMe'),a);hud($('hudEnemy'),b);$('fugaActionCount').textContent=`${a.fuga}/2`;$('turnLabel').textContent='TURNO '+state.turn;$('meCard').src=A+CHARS[a.char].card;$('enemyCard').src=A+CHARS[b.char].card;renderMoves(a);renderActions(a)}
function resourceFor(p,m){let r=p.resources;if(m.attr==='BALÍSTICA'&&r.MUNIÇÃO!==undefined)return'MUNIÇÃO';if(m.attr==='ARCANA'&&r.MANA!==undefined)return'MANA';if(m.attr==='ESTRATÉGIA'&&r.TÁTICA!==undefined)return'TÁTICA';if(m.attr==='FORÇA'&&r.ESTAMINA!==undefined)return'ESTAMINA';if(r.LETALIDADE!==undefined)return'LETALIDADE';return Object.keys(r)[0]}
function renderMoves(p){let g=$('moveGrid');g.innerHTML='';CHARS[p.char].moves.forEach((f,i)=>{let m=moveMeta[i],res=resourceFor(p,m),ok=(p.resources[res]||0)>=m.cost;let b=document.createElement('button');b.className='move'+(!ok?' locked':'');b.innerHTML=`<img src="${A+p.char+'/'+f}">`;b.onclick=()=>inspect(i,ok,res);g.appendChild(b)})}
function renderActions(p){let bs=[...$('actions').querySelectorAll('button')];bs[0].style.display=p.resources.MUNIÇÃO===undefined?'none':'';bs[1].style.display=p.resources.MANA===undefined?'none':'';bs[2].style.display=p.resources.ESTAMINA===undefined?'none':''}
function inspect(i,ok,res){let p=mine(),m=moveMeta[i];$('inspectImg').src=A+p.char+'/'+CHARS[p.char].moves[i];$('inspectTitle').textContent='GOLPE '+(i+1);$('inspectText').innerHTML=`<div class="stat"><b>ATRIBUTO</b><span>${m.attr}</span></div><div class="stat"><b>DANO DO CARD</b><span>${m.damage}</span></div><div class="stat"><b>EFEITO</b><span>${m.effect||'—'}</span></div><div class="stat"><b>CUSTO</b><span>${m.cost} ${res}</span></div>`;$('useMove').disabled=!ok||locked;$('useMove').textContent=ok?'USAR GOLPE':'RECURSO INSUFICIENTE';$('useMove').onclick=()=>{if(ok&&!locked){closeCard();sendPick(i)}};$('cardModal').classList.add('show')}
function closeCard(){$('cardModal').classList.remove('show')}
async function sendPick(i){if(offlineMode)return offlinePick(i);if(locked)return;locked=true;try{await api('/api/pick','POST',{slot:i});$('status').textContent='GOLPE CONFIRMADO — AGUARDANDO OPONENTE'}catch(e){locked=false;log('⚠ '+e.message)}}
async function recover(kind){if(offlineMode)return offlineRecover(kind);if(locked)return;locked=true;try{await api('/api/recover','POST',{kind});pulseHud('me');$('status').textContent=kind+' — TURNO ENTREGUE'}catch(e){log('⚠ '+e.message)}finally{locked=false}}
async function fuga(){if(offlineMode)return offlineFuga();if(locked)return;try{await api('/api/fuga','POST');cinematicFx('FUGA!');pulseHud('me')}catch(e){log('⚠ '+e.message)}}
function log(t){$('log').innerHTML+=t+'<br>';$('log').scrollTop=$('log').scrollHeight}
function moveImg(username,slot){let p=state.players.find(x=>x.username===username);return A+p.char+'/'+CHARS[p.char].moves[slot]}

function cinematicFx(text='IMPACTO'){
 const fx=$('battleFx'),txt=$('fxText'); if(!fx)return;
 txt.textContent=text; fx.className='battle-fx play hit';
 const battle=$('battle'); if(battle){battle.classList.remove('shake'); void battle.offsetWidth; battle.classList.add('shake')}
 setTimeout(()=>{fx.className='battle-fx'; if(battle)battle.classList.remove('shake')},850)
}
function pulseHud(side='me'){
 const h=side==='me'?$('hudMe'):$('hudEnemy'); if(!h)return;
 h.classList.remove('resource-pulse'); void h.offsetWidth; h.classList.add('resource-pulse');
 setTimeout(()=>h.classList.remove('resource-pulse'),600)
}

async function animateReveal(r){
 locked=true;
 const my=r.a.username===me.username?r.a:r.b;
 const other=r.a.username===me.username?r.b:r.a;
 $('revealMe').src=moveImg(me.username,my.slot);
 $('revealEnemy').src=moveImg(other.username,other.slot);
 $('revealMeMeta').textContent=`${my.move.attr} • CARD ${my.move.damage} • CUSTO ${my.move.cost}`;
 $('revealEnemyMeta').textContent=`${other.move.attr} • CARD ${other.move.damage} • CUSTO ${other.move.cost}`;
 $('dieMe').innerHTML='<b>D12</b>';$('dieEnemy').innerHTML='<b>D12</b>';
 $('damageBanner').textContent='';$('resolution').textContent='REVELANDO GOLPES...';
 $('reveal').classList.add('show');
 await wait(650);

 $('resolution').textContent='ROLANDO D12';
 $('dieMe').classList.add('roll');$('dieEnemy').classList.add('roll');
 for(let i=0;i<16;i++){
   await wait(55);
   $('dieMe').innerHTML='<b>'+(1+Math.floor(Math.random()*12))+'</b>';
   $('dieEnemy').innerHTML='<b>'+(1+Math.floor(Math.random()*12))+'</b>';
 }
 $('dieMe').classList.remove('roll');$('dieEnemy').classList.remove('roll');
 $('dieMe').innerHTML=`<b>${my.roll}${my.bonus?` +${my.bonus}`:''}</b>`;
 $('dieEnemy').innerHTML=`<b>${other.roll}${other.bonus?` +${other.bonus}`:''}</b>`;
 $('resolution').textContent=r.winner?`${r.winner} VENCEU O CONFRONTO`:'EMPATE — AMBOS ATACAM';
 await wait(700);

 if(r.winner){
   const dmg=r.winner===my.username?my.damage:other.damage;
   $('damageBanner').textContent=`${r.winner} • ${dmg} DE DANO`;
   cinematicFx('IMPACTO!');
 }else{
   $('damageBanner').textContent=`AMBOS ATACAM • ${my.damage} / ${other.damage} DANO`;
   cinematicFx('EMPATE!');
 }
 log(r.winner?`${r.winner} venceu o confronto.`:'Empate: ambos os golpes acertaram.');
 await wait(1250);
 $('reveal').classList.remove('show');
 $('resolution').textContent='';$('damageBanner').textContent='';
 locked=false;$('status').textContent='ESCOLHA UM GOLPE'
}
async function animateFreeAttack(r){
 locked=true;
 $('status').textContent=`${r.reason}: TURNO ENTREGUE`;
 log(`${r.from} vai atacar após ${r.reason}.`);
 await wait(450);
 cinematicFx('ATAQUE!');
 $('status').textContent=`${r.from} CAUSOU ${r.damage} DE DANO`;
 log(`${r.from} causou ${r.damage} de dano após ${r.reason}.`);
 await wait(1000);
 locked=false;$('status').textContent='ESCOLHA UM GOLPE'
}
function cancelQueue(){clearInterval(poller);poller=null;show('roster')}
function togglePause(){$('pauseModal').classList.toggle('show')}
function leaveBattle(){clearInterval(poller);poller=null;roomId=null;state=null;$('pauseModal').classList.remove('show');if(offlineMode){offlineMode=false;me=savedOnlineMe;savedOnlineMe=null;renderHome()}show('home')}
if(location.protocol==='file:')$('localWarning').classList.remove('hidden');
const wait=ms=>new Promise(r=>setTimeout(r,ms));loadMe();
