(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.BWEngine=api;})(typeof window!=='undefined'?window:globalThis,function(){
'use strict';
const ATTR_BEATS={'FORÇA':'ARCANA',ARCANA:'BALÍSTICA','BALÍSTICA':'ESTRATÉGIA','ESTRATÉGIA':'FORÇA'};
const EFFECTS={
 ATORDOAMENTO:{name:'ATORDOAMENTO',desc:'−3 na próxima rolagem de D12.'},
 MEDO:{name:'MEDO',desc:'−2 na próxima rolagem de D12.'},
 SUPRESSAO:{name:'SUPRESSÃO',desc:'−2 na próxima rolagem de D12.'},
 ESCURIDAO:{name:'ESCURIDÃO',desc:'A próxima escolha de golpe é feita às cegas.'},
 INVISIBILIDADE:{name:'INVISIBILIDADE',desc:'Bloqueia golpes recebidos enquanto houver cargas, exceto ANTI FUGA.'},
 NEVOA:{name:'NÉVOA',desc:'Imune ao próximo golpe de FORÇA. É consumida quando bloqueia.'},
 ARMADILHA:{name:'ARMADILHA',desc:'+3 na próxima resolução de confronto.'},
 MARCACAO:{name:'MARCAÇÃO',desc:'O próximo golpe que acertar recebe +20 de dano.'},
 MARCADO:{name:'MARCADO PARA MORRER',desc:'O próximo golpe de FORÇA que acertar recebe +20 de dano.'},
 RETALIACAO_ARMADA:{name:'RETALIAÇÃO',desc:'Se receber dano no próximo confronto, prepara +30 para o próximo golpe de FORÇA.'},
 RETALIACAO_BONUS:{name:'RETALIAÇÃO +30',desc:'O próximo golpe de FORÇA que acertar recebe +30.'},
 CAPTURA:{name:'CAPTURA',desc:'Perde a próxima ação.'},
 FUGA_AUTOMATICA:{name:'FUGA AUTOMÁTICA',desc:'O próximo golpe contra Hitoshi é evitado como FUGA, exceto ANTI FUGA.'},
 MAO_RAPIDA:{name:'MÃO MAIS RÁPIDA',desc:'+5 na resolução do próximo confronto.'},
 ANTIFUGA_NEXT:{name:'ANTIFUGA PREPARADO',desc:'O próximo golpe que acertar recebe ANTI FUGA.'}
};
const CHARS={
 'FELPHS SILVERHAND':{hp:280,stats:{'FORÇA':0,ARCANA:0,'BALÍSTICA':20,'ESTRATÉGIA':20},resources:{'MUNIÇÃO':6,'TÁTICA':6},passive:'MIRA FRIA'},
 'HITOSHI ARAMAKI':{hp:280,stats:{'FORÇA':10,ARCANA:0,'BALÍSTICA':20,'ESTRATÉGIA':15},resources:{'MUNIÇÃO':6,'TÁTICA':6,ESTAMINA:6},passive:'PISTOLEIRO VERDE DE OSAKA'},
 'JACK BLOOD':{hp:200,stats:{'FORÇA':25,ARCANA:0,'BALÍSTICA':0,'ESTRATÉGIA':20},resources:{LETALIDADE:0,'TÁTICA':6},passive:'O ASSASSINO DE REGIS CITY'},
 'MARSHALL B NICKO':{hp:300,stats:{'FORÇA':20,ARCANA:20,'BALÍSTICA':0,'ESTRATÉGIA':0},resources:{ESTAMINA:6,MANA:6},passive:'INTIMIDAÇÃO DO SERRADOR'},
 'MATH SEVERUS':{hp:300,stats:{'FORÇA':25,ARCANA:0,'BALÍSTICA':10,'ESTRATÉGIA':0},resources:{ESTAMINA:6,'MUNIÇÃO':6},passive:'CAÇADOR CUIUDO'},
 'MUCA BLACKOUT':{hp:300,stats:{'FORÇA':10,ARCANA:0,'BALÍSTICA':20,'ESTRATÉGIA':20},resources:{'MUNIÇÃO':6,'TÁTICA':6,ESTAMINA:6},passive:'PROTOCOLO BLACKOUT'},
 'O PATRIOTA':{hp:320,stats:{'FORÇA':22,ARCANA:0,'BALÍSTICA':0,'ESTRATÉGIA':20},resources:{ESTAMINA:6,'TÁTICA':6},passive:'O ESCUDO DA LIBERDADE'},
 'LEANDRO SMOKER':{hp:200,stats:{'FORÇA':20,ARCANA:0,'BALÍSTICA':10,'ESTRATÉGIA':10},resources:{LETALIDADE:0,'MUNIÇÃO':6,'TÁTICA':6},passive:'CLONE DE FUMAÇA'}
};
const M={
 'FELPHS SILVERHAND':[
  {name:'O MAIOR ATIRADOR DO MUNDO',attr:'BALÍSTICA',damage:30,resource:'MUNIÇÃO',cost:3,autoInstant:10,autoEffects:['QUEBRA_ARMADURA']},
  {name:'BALA DO DRAGÃO',attr:'BALÍSTICA',damage:45,resource:'MUNIÇÃO',cost:3,extra:{cost:1,label:'+20 DE DANO',instant:20}},
  {name:'PASSO FANTASMA',attr:'ESTRATÉGIA',damage:0,resource:'TÁTICA',cost:3,setup:true,limit:1,selfEffects:[['INVISIBILIDADE',2]]},
  {name:'DRAGÃO VERMELHO',attr:'ESTRATÉGIA',damage:35,resource:'TÁTICA',cost:3,extra:{cost:1,label:'SE VENCER: PRÓXIMO GOLPE +20',onWin:'MARCACAO'}},
  {name:'ANTI BLINDAGEM',attr:'BALÍSTICA',damage:20,resource:'MUNIÇÃO',cost:1,breakArmor:true},
  {name:'DEAD SHOT',attr:'BALÍSTICA',damage:130,resource:'MUNIÇÃO',cost:5,limit:1,antiFuga:true,autoInstant:20,breakArmor:true},
  {name:'PONTO CEGO',attr:'ESTRATÉGIA',damage:30,resource:'TÁTICA',cost:2,extra:{cost:1,label:'+3 NESTE CONFRONTO',rollBonus:3}}
 ],
 'HITOSHI ARAMAKI':[
  {name:'CORTE DA SERPENTE',attr:'FORÇA',damage:25,resource:'ESTAMINA',cost:2,extra:{cost:1,label:'SANGRAMENTO +20',instant:20}},
  {name:'TIRO DA SERPENTE',attr:'BALÍSTICA',damage:25,resource:'MUNIÇÃO',cost:2,extra:{cost:1,label:'+20 DE DANO',instant:20}},
  {name:'SAQUE RÁPIDO',attr:'BALÍSTICA',damage:20,resource:'MUNIÇÃO',cost:1,extra:{cost:1,label:'SAQUE DEFENSIVO CONTRA BALÍSTICA',saqueDefensivo:true}},
  {name:'DESCARREGANDO O TAMBOR',attr:'ESTRATÉGIA',damage:20,resource:'TÁTICA',cost:3,onHitSelf:[['FUGA_AUTOMATICA',1]]},
  {name:'DUELO EM OSAKA',attr:'ESTRATÉGIA',damage:25,resource:'TÁTICA',cost:2,extra:{cost:1,label:'+5 NO PRÓXIMO CONFRONTO',onHitSelf:[['MAO_RAPIDA',1]]}},
  {name:'CASCAVEL',attr:'BALÍSTICA',damage:35,resource:'MUNIÇÃO',cost:2,extra:{cost:1,label:'ENVENENAMENTO +15',instant:15}},
  {name:'RONIN DA SERPENTE VERDE',attr:'FORÇA',damage:105,resource:'ESTAMINA',cost:4,limit:1,ultimate:true,extra:{cost:2,label:'ANTIFUGA + SANGRAMENTO +20',antiFuga:true,instant:20}}
 ],
 'JACK BLOOD':[
  {name:'APAGÃO',attr:'ESTRATÉGIA',damage:25,resource:'TÁTICA',cost:3,targetEffects:[['ESCURIDAO',1]]},
  {name:'JOGO DO ASSASSINO',attr:'ESTRATÉGIA',damage:0,resource:'TÁTICA',cost:1,setup:true,selfEffects:[['ARMADILHA',1]]},
  {name:'SEM SAÍDA',attr:'FORÇA',damage:35,resource:'LETALIDADE',cost:2,targetEffects:[['ATORDOAMENTO',1]]},
  {name:'SENTENÇA VERMELHA',attr:'FORÇA',damage:40,resource:'LETALIDADE',cost:2,onWin:'MARCADO'},
  {name:'NINGUÉM SAI VIVO',attr:'FORÇA',damage:100,resource:'LETALIDADE',cost:4,limit:1,ultimate:true,extra:{cost:2,label:'ANTIFUGA + SANGRAMENTO +20',antiFuga:true,instant:20}},
  {name:'GOLPE DO CARRASCO',attr:'FORÇA',damage:20,resource:'LETALIDADE',cost:0,gainLethalityExtra:1},
  {name:'SURPRESA!',attr:'FORÇA',damage:25,resource:'LETALIDADE',cost:1,delayedBleed:20}
 ],
 'MARSHALL B NICKO':[
  {name:'AGARRÃO PIRATA',attr:'FORÇA',damage:20,resource:'ESTAMINA',cost:3,grantFreeForce:true},
  {name:'CANHÕES AMALDIÇOADOS',attr:'ARCANA',damage:30,resource:'MANA',cost:2,extra:{cost:1,label:'QUEIMADURA +10',instant:10}},
  {name:'CORTE DO CAOS',attr:'FORÇA',damage:25,resource:'ESTAMINA',cost:2,afterAgarrãoBonus:15},
  {name:'IMPERADOR DOS SETE MARES',attr:'FORÇA',damage:110,resource:'ESTAMINA',cost:4,limit:1,ultimate:true,extra:{cost:2,label:'+30 E SANGRAMENTO +20',instant:50}},
  {name:'MALDIÇÃO DOS AFOGADOS',attr:'ARCANA',damage:25,resource:'MANA',cost:2,extra:{cost:1,label:'MEDO −2',targetEffects:[['MEDO',1]]}},
  {name:'SERRANDO PRA CARALHO',attr:'FORÇA',damage:15,resource:'ESTAMINA',cost:1,afterAgarrãoBonus:15},
  {name:'KRAKEN NEGRO',attr:'ARCANA',damage:35,resource:'MANA',cost:4,extra:{cost:2,label:'DEVORAR ULTIMATE',devourUltimate:true}}
 ],
 'MATH SEVERUS':[
  {name:'O MAIOR PREDADOR',attr:'FORÇA',damage:110,resource:'ESTAMINA',cost:4,limit:1,ultimate:true,extra:{cost:2,label:'ANTIFUGA +20',antiFuga:true,instant:20}},
  {name:'LAÇO DO PREDADOR',attr:'FORÇA',damage:20,resource:'ESTAMINA',cost:2,extra:{cost:1,label:'−3 NA PRÓXIMA ROLAGEM',targetEffects:[['ATORDOAMENTO',1]]}},
  {name:'LANÇA DO PREDADOR',attr:'FORÇA',damage:15,resource:'ESTAMINA',cost:1},
  {name:'REDE DO PREDADOR',attr:'BALÍSTICA',damage:25,resource:'MUNIÇÃO',cost:2,extra:{cost:1,label:'CAPTURA: PERDE PRÓXIMA AÇÃO',targetEffects:[['CAPTURA',1]]}},
  {name:'BUMERANGUE DO CAÇADOR',attr:'FORÇA',damage:20,resource:'ESTAMINA',cost:2,extra:{cost:1,label:'+20 DE DANO',instant:20}},
  {name:'FLECHA DO CAÇADOR',attr:'BALÍSTICA',damage:25,resource:'MUNIÇÃO',cost:1,extra:{cost:1,label:'SANGRAMENTO +20',instant:20}},
  {name:'CAÇADA SELVAGEM',attr:'FORÇA',damage:25,resource:'ESTAMINA',cost:3,extra:{cost:1,label:'ATORDOAMENTO + SANGRAMENTO',instant:20,targetEffects:[['ATORDOAMENTO',1]]}}
 ],
 'MUCA BLACKOUT':[
  {name:'RIFLE NANOTECH',attr:'BALÍSTICA',damage:120,resource:'MUNIÇÃO',cost:4,limit:1,ultimate:true,extra:{cost:1,label:'SANGRAMENTO + QUEIMADURA',instant:30}},
  {name:'ESSE TORNEIO EU VOU GANHAR',attr:'FORÇA',damage:25,resource:'ESTAMINA',cost:2,extra:{cost:1,label:'SANGRAMENTO +20',instant:20}},
  {name:'BRUTALIDADE TÁTICA',attr:'FORÇA',damage:35,resource:'ESTAMINA',cost:3,extra:{cost:1,label:'+20 DE DANO',instant:20}},
  {name:'DROPPER',attr:'ESTRATÉGIA',damage:40,resource:'TÁTICA',cost:3,extra:{cost:2,label:'DANO PERFURADOR + SANGRAMENTO',instant:20,piercing:true}},
  {name:'GRANADA DE IMPACTO',attr:'ESTRATÉGIA',damage:10,resource:'TÁTICA',cost:1,extra:{cost:1,label:'ATORDOAMENTO',targetEffects:[['ATORDOAMENTO',1]]}},
  {name:'RAJADA BLACKOUT',attr:'BALÍSTICA',damage:30,resource:'MUNIÇÃO',cost:2,extra:{cost:1,label:'SUPRESSÃO −2',targetEffects:[['SUPRESSAO',1]]}},
  {name:'TIRO CONTROLADO',attr:'BALÍSTICA',damage:25,resource:'MUNIÇÃO',cost:1,multiTarget:true,extra:{cost:1,label:'+1 MUNIÇÃO POR ALVO ADICIONAL'}}
 ],
 'O PATRIOTA':[
  {name:'BUMERANGUE',attr:'ESTRATÉGIA',damage:30,resource:'TÁTICA',cost:2,extra:{cost:2,label:'ANTIFUGA',antiFuga:true}},
  {name:'ARREMESSO PATRIÓTICO',attr:'FORÇA',damage:20,resource:'ESTAMINA',cost:1,extra:{cost:1,label:'ATORDOAMENTO',targetEffects:[['ATORDOAMENTO',1]]}},
  {name:'ÚLTIMA LINHA DE DEFESA',attr:'ESTRATÉGIA',damage:0,resource:'TÁTICA',cost:1,setup:true,limit:2,selfEffects:[['RETALIACAO_ARMADA',1]]},
  {name:'ESTRELA CADENTE',attr:'FORÇA',damage:35,resource:'ESTAMINA',cost:2,extra:{cost:1,label:'QUEIMADURA +10',instant:10}},
  {name:'INVESTIDA DA LIBERDADE',attr:'FORÇA',damage:40,resource:'ESTAMINA',cost:2,extra:{cost:2,label:'QUEBRA DE GOLPE',breakMove:true}},
  {name:'COLISÃO DA LIBERDADE',attr:'FORÇA',damage:110,resource:'ESTAMINA',cost:3,limit:1,ultimate:true,extra:{cost:2,label:'+30 DE DANO',instant:30}},
  {name:'SOCO DA LIBERDADE',attr:'FORÇA',damage:25,resource:'ESTAMINA',cost:1}
 ],
 'LEANDRO SMOKER':[
  {name:'MANTO DA NEBLINA',attr:'ESTRATÉGIA',damage:0,resource:'TÁTICA',cost:1,setup:true,selfEffects:[['NEVOA',1]]},
  {name:'SHURIKENS DA FUMAÇA',attr:'BALÍSTICA',damage:15,resource:'MUNIÇÃO',cost:2,gainLethalityExtra:1},
  {name:'DEMÔNIO DA NEBLINA',attr:'FORÇA',damage:110,resource:'LETALIDADE',cost:4,limit:1,ultimate:true,extra:{cost:2,label:'ANTIFUGA +30 E NÉVOA',antiFuga:true,instant:30,onHitSelf:[['NEVOA',1]]}},
  {name:'CLONE EXPLOSIVO',attr:'ESTRATÉGIA',damage:30,resource:'TÁTICA',cost:2,extra:{cost:1,label:'ESCURIDÃO',targetEffects:[['ESCURIDAO',1]]}},
  {name:'CORTE DA NEBLINA',attr:'FORÇA',damage:20,resource:'LETALIDADE',cost:0},
  {name:'ASSASSINO DA FUMAÇA',attr:'FORÇA',damage:40,resource:'LETALIDADE',cost:2,extra:{cost:1,label:'+20 DE DANO',instant:20}},
  {name:'12 NEM ME VIU, JÁ SUMI NA NEBLINA',attr:'ESTRATÉGIA',damage:20,resource:'TÁTICA',cost:2,onWin:'ANTIFUGA_NEXT'}
 ]
};
function clone(x){return JSON.parse(JSON.stringify(x));}
function makePlayer(id,username,char,points=0,rank='OFFLINE'){const c=CHARS[char];if(!c)throw new Error('Personagem inválido');return{id,username,points,rank,char,hp:c.hp,maxHp:c.hp,stats:clone(c.stats),resources:clone(c.resources),fuga:2,fugaClock:0,pick:null,effects:[],uses:{},disabledUntil:{},passive:{used:false,active:false,ready:false},devouredUltimate:false,pendingDamage:[],alive:true,damageDealt:0,defeated:[],lastSuccessfulMove:null};}
function effectMeta(id){return EFFECTS[id]||{name:id.replaceAll('_',' '),desc:''};}
function addEffect(p,id,charges=1){let e=p.effects.find(x=>x.id===id);if(e)e.charges=Math.max(e.charges||1,charges);else{let m=effectMeta(id);p.effects.push({id,name:m.name,desc:m.desc,charges});}}
function hasEffect(p,id){return p.effects.some(x=>x.id===id);}
function takeEffect(p,id){let i=p.effects.findIndex(x=>x.id===id);if(i<0)return null;let e=p.effects[i];e.charges=(e.charges||1)-1;if(e.charges<=0)p.effects.splice(i,1);return e;}
function applyList(p,list){for(const x of list||[])addEffect(p,x[0],x[1]||1);}
function alive(room){return room.players.filter(p=>p.hp>0&&p.alive!==false);}
function getP(room,id){return room.players.find(p=>String(p.id)===String(id));}
function movesFor(p){return M[p.char]||[];}
function moveCost(m,pick){if(m.multiTarget){return m.cost+Math.max(0,(pick?.extraTargets||[]).length);}return m.cost+(pick?.extra&&m.extra?m.extra.cost:0);}
function canUse(p,slot,pick={},turn=1,freeKind=null){let m=movesFor(p)[slot];if(!m||p.hp<=0)return false;if(m.limit&&(p.uses[slot]||0)>=m.limit)return false;if(m.ultimate&&p.devouredUltimate)return false;if((p.disabledUntil?.[slot]||0)>=turn)return false;if(freeKind==='marshall'&&m.attr!=='FORÇA')return false;if(freeKind==='hitoshi'&&m.attr!=='BALÍSTICA')return false;let cost=moveCost(m,pick);if(freeKind==='hitoshi'||freeKind==='marshall')cost=0;return (p.resources[m.resource]||0)>=cost;}
function spendMove(p,slot,pick={},freeKind=null){let m=movesFor(p)[slot],cost=moveCost(m,pick);if(freeKind==='hitoshi'||freeKind==='marshall')cost=0;p.resources[m.resource]-=cost;p.uses[slot]=(p.uses[slot]||0)+1;}
function rollD12(){return 1+Math.floor(Math.random()*12);}
function consumeRollMod(p,m,pick){let mod=0;if(takeEffect(p,'ATORDOAMENTO'))mod-=3;if(takeEffect(p,'MEDO'))mod-=2;if(takeEffect(p,'SUPRESSAO'))mod-=2;if(takeEffect(p,'ARMADILHA'))mod+=3;if(takeEffect(p,'MAO_RAPIDA'))mod+=5;if(pick?.extra&&m?.extra?.rollBonus)mod+=m.extra.rollBonus;return mod;}
function antiFuga(attacker,m,pick){if(attacker.char==='MARSHALL B NICKO'&&attacker.passive.active&&m.attr==='FORÇA')return true;if(hasEffect(attacker,'ANTIFUGA_NEXT'))return true;return !!(m.antiFuga||(pick?.extra&&m.extra?.antiFuga));}
function calcDamage(attacker,m,pick,ctx={}){if(!m.damage||m.damage<=0)return 0;let d=(attacker.stats[m.attr]||0)+m.damage+(m.autoInstant||0);if(pick?.extra&&m.extra)d+=m.extra.instant||0;if(ctx.afterAgarrão&&m.afterAgarrãoBonus)d+=m.afterAgarrãoBonus;if(hasEffect(attacker,'MARCACAO'))d+=20;if(m.attr==='FORÇA'&&hasEffect(attacker,'MARCADO'))d+=20;if(m.attr==='FORÇA'&&hasEffect(attacker,'RETALIACAO_BONUS'))d+=30;return d;}
function consumeDamageBonuses(attacker,m){if(hasEffect(attacker,'MARCACAO'))takeEffect(attacker,'MARCACAO');if(m.attr==='FORÇA'&&hasEffect(attacker,'MARCADO'))takeEffect(attacker,'MARCADO');if(m.attr==='FORÇA'&&hasEffect(attacker,'RETALIACAO_BONUS'))takeEffect(attacker,'RETALIACAO_BONUS');if(hasEffect(attacker,'ANTIFUGA_NEXT'))takeEffect(attacker,'ANTIFUGA_NEXT');}
function checkMath(p,notes){if(p.char==='MATH SEVERUS'&&!p.passive.used&&p.hp<=100&&p.hp>0){let before=p.resources.ESTAMINA||0;p.resources.ESTAMINA=6;p.passive.used=true;p.passive.active=true;notes.push(`🐗 ${p.username}: CAÇADOR CUIUDO encheu automaticamente toda a ESTAMINA (${before}→6), sem gastar ação.`);}}
function checkLeandro(p,notes){if(p.hp<=0&&p.char==='LEANDRO SMOKER'&&!p.passive.used){p.hp=50;p.passive.used=true;p.passive.active=true;p.alive=true;addEffect(p,'NEVOA',1);notes.push(`🌫 ${p.username}: CLONE DE FUMAÇA — retornou com 50 de vida e NÉVOA.`);return true}return false;}
function hurt(p,amount,notes,source){if(amount<=0)return;p.hp-=amount;notes.push(`💥 ${p.username} recebeu ${amount} de dano${source?` de ${source}`:''}.`);checkMath(p,notes);checkLeandro(p,notes);}
function applyTargetEffects(room,attacker,target,m,pick,ctx,notes){applyList(target,m.targetEffects);if(pick?.extra&&m.extra)applyList(target,m.extra.targetEffects);if(m.delayedBleed){target.pendingDamage.push({turn:room.turn+1,amount:m.delayedBleed,source:'SANGRAMENTO'});notes.push(`🩸 ${target.username} sofrerá ${m.delayedBleed} de SANGRAMENTO no próximo turno.`);}if(pick?.extra&&m.extra?.devourUltimate){target.devouredUltimate=true;notes.push(`🐙 ${target.username} teve sua ULTIMATE devorada até o fim da partida.`);}if(pick?.extra&&m.extra?.breakMove&&target.pick?.type==='move'){target.disabledUntil[target.pick.slot]=room.turn+1;notes.push(`⚔ ${movesFor(target)[target.pick.slot]?.name||'Golpe'} de ${target.username} foi desabilitado no próximo turno.`);}}
function applySelfOnHit(attacker,m,pick){applyList(attacker,m.onHitSelf);if(pick?.extra&&m.extra)applyList(attacker,m.extra.onHitSelf);}
function queueFree(room,fa){if(!room.freeActions)room.freeActions=[];if(room.suppressFreeActions)return;room.freeActions.push(fa);}
function duelHitoshi(room,target,attacker,notes){let ht=0,at=0;do{ht=rollD12();at=rollD12();}while(ht===at);target.passive.used=true;target.passive.active=true;if(ht>at){notes.push(`🐍 ${target.username}: PISTOLEIRO VERDE DE OSAKA venceu o duelo ${ht}×${at}, cancelou o golpe e ganhou um contra-ataque BALÍSTICO gratuito.`);queueFree(room,{kind:'hitoshi',actorId:target.id,targetId:attacker.id,reason:'PISTOLEIRO VERDE DE OSAKA'});return true}notes.push(`🐍 ${target.username}: PISTOLEIRO VERDE DE OSAKA perdeu o duelo ${ht}×${at}; o golpe segue normalmente.`);return false;}
function hit(room,attacker,target,m,pick,ctx={}){let notes=ctx.notes||[],anti=antiFuga(attacker,m,pick);
 if(target.hp<=0)return{hit:false,damage:0,blocked:'ALVO DERROTADO'};
 if(ctx.targetFuga&&!anti)return{hit:false,damage:0,blocked:'FUGA'};
 if(hasEffect(target,'FUGA_AUTOMATICA')){takeEffect(target,'FUGA_AUTOMATICA');if(!anti){notes.push(`💨 ${target.username} usou FUGA AUTOMÁTICA.`);return{hit:false,damage:0,blocked:'FUGA AUTOMÁTICA'}}}
 if(ctx.mutual&&target.char==='HITOSHI ARAMAKI'&&target.pick?.type==='move'){let dm=movesFor(target)[target.pick.slot];if(dm?.name==='SAQUE RÁPIDO'&&target.pick.extra&&m.attr==='BALÍSTICA'){notes.push(`🔫 ${target.username} aparou o golpe BALÍSTICO com SAQUE RÁPIDO.`);return{hit:false,damage:0,blocked:'SAQUE RÁPIDO'}}}
 if(target.char==='HITOSHI ARAMAKI'&&!target.passive.used&&(m.attr==='BALÍSTICA'||m.attr==='ARCANA')&&!ctx.freeAction){if(duelHitoshi(room,target,attacker,notes))return{hit:false,damage:0,blocked:'DUELO DE DADOS'}}
 if(target.char==='O PATRIOTA'&&target.passive.ready&&!target.passive.used&&!(pick?.extra&&m.extra?.piercing)){target.passive.ready=false;target.passive.used=true;target.passive.active=true;let reflected=calcDamage(attacker,m,pick,ctx);consumeDamageBonuses(attacker,m);hurt(attacker,reflected,notes,'ESCUDO DA LIBERDADE');applyTargetEffects(room,target,attacker,m,pick,ctx,notes);notes.push(`🛡 ${target.username} anulou e rebateu o golpe completo contra ${attacker.username}.`);return{hit:false,damage:0,reflectedDamage:reflected,blocked:'ESCUDO DA LIBERDADE'}}
 if(m.attr==='FORÇA'&&hasEffect(target,'NEVOA')&&!(pick?.extra&&m.extra?.piercing)){takeEffect(target,'NEVOA');notes.push(`🌫 NÉVOA bloqueou o golpe de FORÇA contra ${target.username}.`);return{hit:false,damage:0,blocked:'NÉVOA'}}
 if(hasEffect(target,'INVISIBILIDADE')&&!anti&&!(pick?.extra&&m.extra?.piercing)){takeEffect(target,'INVISIBILIDADE');notes.push(`◌ INVISIBILIDADE bloqueou o golpe contra ${target.username}.`);if(target.char==='FELPHS SILVERHAND'&&!target.passive.used){let counter=75+(target.stats['BALÍSTICA']||0);target.passive.used=true;target.passive.active=true;hurt(attacker,counter,notes,'MIRA FRIA');notes.push(`🎯 MIRA FRIA: 3×25 + BALÍSTICA base = ${counter}.`);}return{hit:false,damage:0,blocked:'INVISIBILIDADE'}}
 let d=calcDamage(attacker,m,pick,ctx);consumeDamageBonuses(attacker,m);hurt(target,d,notes,m.name);if(d>0){attacker.damageDealt=(attacker.damageDealt||0)+d;attacker.lastSuccessfulMove=m.name;if(target.hp<=0&&!attacker.defeated.includes(target.username))attacker.defeated.push(target.username);}applyTargetEffects(room,attacker,target,m,pick,ctx,notes);applySelfOnHit(attacker,m,pick);if(hasEffect(target,'RETALIACAO_ARMADA')&&d>0){takeEffect(target,'RETALIACAO_ARMADA');addEffect(target,'RETALIACAO_BONUS',1);notes.push(`⛨ ${target.username} preparou RETALIAÇÃO +30 no próximo golpe de FORÇA.`);}if(m.grantFreeForce&&!ctx.freeAction){queueFree(room,{kind:'marshall',actorId:attacker.id,targetId:target.id,reason:'AGARRÃO PIRATA'});notes.push(`⚓ ${attacker.username} ganhou uma ação gratuita de FORÇA pelo AGARRÃO PIRATA.`);}return{hit:true,damage:d};
}
function gainWin(room,p,m,pick,jokempo,notes){if(p.char==='JACK BLOOD'){let before=p.hp;p.hp=Math.min(p.maxHp,p.hp+25);if(p.hp>before)notes.push(`🩸 ${p.username} recuperou ${p.hp-before} VIDA pela passiva.`);}if(p.char==='MUCA BLACKOUT'&&m.attr==='BALÍSTICA'){p.passive.ready=true;notes.push(`🌑 ${p.username} deixou BLACKOUT pronto para ativação.`);}if(p.resources.LETALIDADE!==undefined){let add=1+(m.gainLethalityExtra||0),before=p.resources.LETALIDADE;p.resources.LETALIDADE=Math.min(6,before+add);if(p.resources.LETALIDADE>before)notes.push(`◆ ${p.username} ganhou ${p.resources.LETALIDADE-before} LETALIDADE.`);}if(jokempo&&p.resources['TÁTICA']!==undefined){let before=p.resources['TÁTICA'];p.resources['TÁTICA']=Math.min(6,before+2);if(p.resources['TÁTICA']>before)notes.push(`▱ ${p.username} ganhou ${p.resources['TÁTICA']-before} TÁTICA pela vantagem de atributo.`);}let onWin=(pick?.extra&&m.extra?.onWin)||m.onWin;if(onWin)addEffect(p,onWin,1);}
function tickFuga(p){if(p.hp<=0)return;p.fugaClock=(p.fugaClock||0)+1;if(p.fugaClock>=2){p.fuga=Math.min(2,p.fuga+1);p.fugaClock=0;}}
function applySetup(p,m,pick,notes){applyList(p,m.selfEffects);if(pick?.extra&&m.extra)applyList(p,m.extra.selfEffects);notes.push(`⚙ ${p.username} ativou ${m.name}.`);}
function targetsForPick(room,p,pick,m){let ids=[];if(pick.targetId!=null)ids.push(pick.targetId);if(m.multiTarget)for(const id of pick.extraTargets||[])if(!ids.some(x=>String(x)===String(id)))ids.push(id);return ids.map(id=>getP(room,id)).filter(t=>t&&t.hp>0&&String(t.id)!==String(p.id));}
function attackIntentMap(room){let list=[];for(const p of alive(room)){let pk=p.pick;if(pk?.type!=='move')continue;let m=movesFor(p)[pk.slot];if(m.setup&&(!m.damage||m.damage<=0))continue;for(const t of targetsForPick(room,p,pk,m))list.push({attacker:p,target:t,pick:pk,move:m});}return list;}
function resolvePair(room,x,y,event,processed){let a=x.attacker,b=x.target,pa=x.pick,pb=y.pick,ma=x.move,mb=y.move,key=[String(a.id),String(b.id)].sort().join('|');processed.add(key);let ra=rollD12(),rb=rollD12(),modA=consumeRollMod(a,ma,pa),modB=consumeRollMod(b,mb,pb),ja=ATTR_BEATS[ma.attr]===mb.attr?5:0,jb=ATTR_BEATS[mb.attr]===ma.attr?5:0,sa=ra+modA+ja,sb=rb+modB+jb;let combat={aId:a.id,bId:b.id,aName:a.username,bName:b.username,aMove:ma.name,bMove:mb.name,aRoll:ra,aBonus:modA+ja,bRoll:rb,bBonus:modB+jb,winner:null};
 if(sa>sb){combat.winner=a.id;let h=hit(room,a,b,ma,pa,{notes:event.messages,mutual:true});combat.aDamage=h.damage;gainWin(room,a,ma,pa,ja>0,event.messages)}else if(sb>sa){combat.winner=b.id;let h=hit(room,b,a,mb,pb,{notes:event.messages,mutual:true});combat.bDamage=h.damage;gainWin(room,b,mb,pb,jb>0,event.messages)}else{let ha=hit(room,a,b,ma,pa,{notes:event.messages,mutual:true}),hb=hit(room,b,a,mb,pb,{notes:event.messages,mutual:true});combat.aDamage=ha.damage;combat.bDamage=hb.damage;combat.tie=true;}event.combats.push(combat);
}
function resolveRound(room){let event={type:'round',id:'ev_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),turn:room.turn,combats:[],attacks:[],messages:[]};room.freeActions=[];
 // recoveries and setup happen before attacks
 for(const p of alive(room)){let pk=p.pick;if(!pk)continue;if(pk.type==='recover'){let map={RECARREGAR:['MUNIÇÃO',6],MEDITAR:['MANA',4],'FÔLEGO':['ESTAMINA',3]},v=map[pk.kind];if(v&&p.resources[v[0]]!==undefined){let before=p.resources[v[0]];p.resources[v[0]]=Math.min(6,before+v[1]);event.messages.push(`🔋 ${p.username} usou ${pk.kind}: ${v[0]} ${before}→${p.resources[v[0]]}.`);}}else if(pk.type==='move'){let m=movesFor(p)[pk.slot];if(m.setup&&(!m.damage||m.damage<=0))applySetup(p,m,pk,event.messages);}else if(pk.type==='skip')event.messages.push(`⏭ ${p.username} perdeu a ação por CAPTURA.`);}
 let intents=attackIntentMap(room),processed=new Set();
 // mutual target pairs are confrontations
 for(const x of intents){let key=[String(x.attacker.id),String(x.target.id)].sort().join('|');if(processed.has(key))continue;let y=intents.find(z=>String(z.attacker.id)===String(x.target.id)&&String(z.target.id)===String(x.attacker.id));if(y)resolvePair(room,x,y,event,processed);}
 // all remaining attacks are uncontested (or target chose FUGA)
 for(const x of intents){let key=[String(x.attacker.id),String(x.target.id)].sort().join('|');if(processed.has(key))continue;let targetFuga=x.target.pick?.type==='fuga';let h=hit(room,x.attacker,x.target,x.move,x.pick,{notes:event.messages,targetFuga,mutual:false});event.attacks.push({fromId:x.attacker.id,toId:x.target.id,from:x.attacker.username,to:x.target.username,move:x.move.name,damage:h.damage,blocked:h.blocked||null});}
 // consume darkness when a move choice was actually made
 for(const p of alive(room))if(p.pick?.type==='move')takeEffect(p,'ESCURIDAO');
 for(const p of room.players){tickFuga(p);p.pick=null;}
 room.turn++;
 // delayed damage at start of the new turn
 for(const p of room.players){let remain=[];for(const pd of p.pendingDamage||[]){if(pd.turn<=room.turn&&p.hp>0)hurt(p,pd.amount,event.messages,pd.source);else remain.push(pd);}p.pendingDamage=remain;}
 // CAPTURA automatically skips the new turn
 for(const p of alive(room))if(takeEffect(p,'CAPTURA'))p.pick={type:'skip',reason:'CAPTURA'};
 room.lastEvent=event;room.updated=Date.now();return event;
}
function allReady(room){let aps=alive(room);return aps.length>0&&aps.every(p=>p.pick!==null);}
function validateTarget(room,p,targetId){let t=getP(room,targetId);return !!(t&&t.hp>0&&String(t.id)!==String(p.id));}
function commitAction(room,p,action){if(!p||p.hp<=0)throw new Error('Jogador fora de combate.');if(p.pick)throw new Error('Você já escolheu a ação.');if(action.type==='move'){let slot=Number(action.slot),m=movesFor(p)[slot];if(!m)throw new Error('Golpe inválido.');let pick={type:'move',slot,extra:!!action.extra,targetId:action.targetId,extraTargets:Array.isArray(action.extraTargets)?action.extraTargets:[]};if(!(m.setup&&(!m.damage||m.damage<=0))){if(!validateTarget(room,p,pick.targetId))throw new Error('Selecione um alvo válido.');if(m.multiTarget){let uniq=[];for(const id of pick.extraTargets){if(validateTarget(room,p,id)&&String(id)!==String(pick.targetId)&&!uniq.some(x=>String(x)===String(id)))uniq.push(id);}pick.extraTargets=uniq;}}else{pick.targetId=null;pick.extraTargets=[];}if(!canUse(p,slot,pick,room.turn))throw new Error(`Sem ${m.resource} suficiente ou golpe indisponível.`);spendMove(p,slot,pick);p.pick=pick;return pick;}if(action.type==='fuga'){if(p.fuga<=0)throw new Error('FUGA sem cargas.');p.fuga--;p.pick={type:'fuga'};return p.pick;}if(action.type==='recover'){let map={RECARREGAR:'MUNIÇÃO',MEDITAR:'MANA','FÔLEGO':'ESTAMINA'},r=map[action.kind];if(!r||p.resources[r]===undefined)throw new Error('Ação indisponível.');if(p.resources[r]>=6)throw new Error(`${r} já está 6/6.`);p.pick={type:'recover',kind:action.kind};return p.pick;}throw new Error('Ação inválida.');}
function executeFreeAction(room,p,action){let fa=room.freeActions?.[0];if(!fa||String(fa.actorId)!==String(p.id))throw new Error('Ação gratuita indisponível.');let slot=Number(action.slot),m=movesFor(p)[slot],pick={type:'move',slot,extra:!!action.extra,targetId:action.targetId,extraTargets:[]};if(!m)throw new Error('Golpe inválido.');if(fa.kind==='marshall'){if(m.attr!=='FORÇA')throw new Error('AGARRÃO PIRATA permite apenas golpe de FORÇA.');if(!validateTarget(room,p,pick.targetId))throw new Error('Selecione um alvo válido.');if(!canUse(p,slot,pick,room.turn,'marshall'))throw new Error('Recurso insuficiente.');spendMove(p,slot,pick,'marshall');}else if(fa.kind==='hitoshi'){if(m.attr!=='BALÍSTICA')throw new Error('O contra-ataque de Hitoshi precisa ser BALÍSTICO.');pick.targetId=fa.targetId;if(!canUse(p,slot,pick,room.turn,'hitoshi'))throw new Error('Golpe indisponível ou recurso extra insuficiente.');spendMove(p,slot,pick,'hitoshi');}else throw new Error('Ação gratuita inválida.');let target=getP(room,pick.targetId),notes=[];room.suppressFreeActions=true;let h=hit(room,p,target,m,pick,{notes,freeAction:true,afterAgarrão:fa.kind==='marshall'});room.suppressFreeActions=false;room.freeActions.shift();let ev={type:'freeAttack',id:'fa_'+Date.now()+'_'+Math.random().toString(36).slice(2,7),from:p.username,to:target.username,fromId:p.id,toId:target.id,move:m.name,slot,damage:h.damage,reason:fa.reason,messages:notes};room.lastEvent=ev;room.updated=Date.now();return ev;}
function activatePassive(room,p,targetId){if(p.char==='MARSHALL B NICKO'){if(p.passive.active)throw new Error('Passiva já está ativa.');p.passive.active=true;p.passive.used=true;return'INTIMIDAÇÃO DO SERRADOR ativada';}if(p.char==='MUCA BLACKOUT'){if(!p.passive.ready)throw new Error('BLACKOUT ainda não está pronto.');let target=getP(room,targetId);if(!target||target.hp<=0||String(target.id)===String(p.id))throw new Error('Selecione o alvo do BLACKOUT.');p.passive.ready=false;addEffect(target,'ESCURIDAO',1);return`BLACKOUT aplicado em ${target.username}`;}if(p.char==='O PATRIOTA'){if(p.passive.used||p.passive.ready)throw new Error('Escudo já foi ativado/usado.');p.passive.ready=true;return'O ESCUDO DA LIBERDADE está preparado';}throw new Error('Esta passiva é automática.');}
function statusLabel(p){if(p.passive.used)return'USADA';if(p.passive.active)return'ATIVA';if(p.passive.ready)return'PRONTA';return'DISPONÍVEL';}
function cpuAction(room,p){if(p.pick||p.hp<=0)return p.pick;let targets=alive(room).filter(x=>String(x.id)!==String(p.id));if(!targets.length)return null;let choices=movesFor(p).map((m,i)=>({m,i})).filter(x=>canUse(p,x.i,{type:'move',slot:x.i,extra:false,targetId:targets[0].id},room.turn));if(!choices.length){let kinds=[];if(p.resources.MUNIÇÃO!==undefined&&p.resources.MUNIÇÃO<6)kinds.push('RECARREGAR');if(p.resources.MANA!==undefined&&p.resources.MANA<6)kinds.push('MEDITAR');if(p.resources.ESTAMINA!==undefined&&p.resources.ESTAMINA<6)kinds.push('FÔLEGO');if(kinds.length)return commitAction(room,p,{type:'recover',kind:kinds[Math.floor(Math.random()*kinds.length)]});return commitAction(room,p,{type:'fuga'});}let c=choices[Math.floor(Math.random()*choices.length)],target=targets[Math.floor(Math.random()*targets.length)],extra=!!(c.m.extra&&Math.random()<0.45&&(p.resources[c.m.resource]||0)>=c.m.cost+c.m.extra.cost);let extraTargets=[];if(c.m.multiTarget){let others=targets.filter(t=>String(t.id)!==String(target.id));let ammo=(p.resources.MUNIÇÃO||0)-c.m.cost;for(const t of others)if(ammo>0&&Math.random()<0.5){extraTargets.push(t.id);ammo--;}}return commitAction(room,p,{type:'move',slot:c.i,extra,targetId:target.id,extraTargets});}
return{ATTR_BEATS,EFFECTS,CHARS,M,clone,makePlayer,addEffect,hasEffect,takeEffect,movesFor,moveCost,canUse,spendMove,alive,getP,commitAction,resolveRound,allReady,executeFreeAction,activatePassive,statusLabel,cpuAction,antiFuga,calcDamage};
});
