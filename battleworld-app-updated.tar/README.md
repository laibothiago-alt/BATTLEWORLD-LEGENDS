# BATTLEWORLD ONLINE

MVP multiplayer do BATTLEWORLD com cadastro/login, ranking Elo, matchmaking 1v1, escolha secreta de golpes e resolução autoritativa no servidor.

## Rodar localmente

Requer Node.js 22+.

```bash
node server.js
```
Abra http://localhost:3000 em dois navegadores/abas, crie duas contas e entre no Ranqueado 1v1.

## Persistência

Por padrão, contas e ranking ficam em `battleworld.sqlite`.
Em hospedagem, configure `DB_PATH` para um caminho em volume persistente, por exemplo `/data/battleworld.sqlite`.
Configure também `JWT_SECRET` com uma string longa e aleatória.

## Regras já implementadas no multiplayer

- recursos começam no máximo 6;
- personagens híbridos mantêm mais de um recurso;
- Recarregar: Munição +6, máximo 6, entrega o turno;
- Meditar: Mana +4, máximo 6, entrega o turno;
- Fôlego: Estamina +3, máximo 6, entrega o turno;
- após recuperação o oponente ataca com um golpe pagável;
- Letalidade +1 ao vencer confronto, máximo 6;
- Tática +2 ao vencer Jokempô, máximo 6;
- Fuga 2 cargas, recupera +1 a cada 2 turnos;
- escolhas de golpe ficam ocultas no servidor até ambos confirmarem;
- D12 + Jokempô define vencedor do confronto;
- +5 do Jokempô afeta somente resolução;
- dano = atributo do personagem + dano do card + bônus/efeitos instantâneos;
- empate: ambos acertam;
- ranking Elo começa em 1000.

## Observação

Os metadados numéricos dos sete golpes ainda estão centralizados no servidor em `MOVES`. As artes são as do pacote BBWL atual. Para produção final, cada card deve ter seus valores exatos transcritos para essa tabela, incluindo custo e efeito próprios.


## IMPORTANTE
Não abra apenas o `index.html` para jogar online. O multiplayer usa o servidor. Execute `npm start` e abra `http://localhost:3000`. A interface agora usa caminhos relativos para que a prévia visual também carregue corretamente quando aberta localmente.
