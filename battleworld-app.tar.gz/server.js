const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {DatabaseSync}=require('node:sqlite');

const PORT=process.env.PORT||3000;
const SECRET=process.env.JWT_SECRET||'battleworld-dev-secret-change-me';
const ROOT=path.join(__dirname,'public');
const db=new DatabaseSync(process.env.DB_PATH||path.join(__dirname,'battleworld.sqlite'));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE COLLATE NOCASE,
 passhash TEXT NOT NULL,
 salt TEXT NOT NULL,
 rating INTEGER NOT NULL DEFAULT 1000,
 wins INTEGER NOT NULL DEFAULT 0,
 losses INTEGER NOT NULL DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS matches(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 winner_id INTEGER,
 loser_id INTEGER,
 winner_before INTEGER,
 loser_before INTEGER,
 winner_after INTEGER,
 loser_after INTEGER,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);
function ensureColumn(table,name,sql){try{db.prepare(`select ${name} from ${table} limit 1`).get()}catch{db.exec(`alter table ${table} add column ${name} ${sql}`)}}
ensureColumn('users','points','INTEGER NOT NULL DEFAULT 0');
ensureColumn('users','recovery_hash','TEXT');
ensureColumn('users','recovery_salt','TEXT');

const waiting=[];
const userRoom=new Map();
const rooms=new Map();

const CHARS={
 'FELPHS SILVERHAND':{hp:280,stats:{'FORÇA':0,ARCANA:0,'BALÍSTICA':20,'ESTRATÉGIA':20},resources:{'MUNIÇÃO':6,'TÁTICA':6}},
 'JACK BLOOD':{hp:200,stats:{'FORÇA':25,ARCANA:0,'BALÍSTICA':0,'ESTRATÉGIA':20},resources:{LETALIDADE:0,'TÁTICA':6}},
 'MARSHALL B NICKO':{hp:300,stats:{'FORÇA':20,ARCANA:20,'BALÍSTICA':0,'ESTRATÉGIA':0},resources:{ESTAMINA:6,MANA:6}},
 'MATH SEVERUS':{hp:300,stats:{'FORÇA':25,ARCANA:0,'BALÍSTICA':10,'ESTRATÉGIA':0},resources:{ESTAMINA:6,'MUNIÇÃO':6}},
 'MUCA BLACKOUT':{hp:300,stats:{'FORÇA':10,ARCANA:0,'BALÍSTICA':20,'ESTRATÉGIA':20},resources:{'MUNIÇÃO':6,'TÁTICA':6,ESTAMINA:6}},
 'O PATRIOTA':{hp:300,stats:{'FORÇA':28,ARCANA:0,'BALÍSTICA':25,'ESTRATÉGIA':10},resources:{ESTAMINA:6,'TÁTICA':6}}
};

const M={
 'FELPHS SILVERHAND':[
  {name:'O MAIOR ATIRADOR DO MUNDO',attr:'BALÍSTICA',damage:30,resource:'MUNIÇÃO',cost:3,instant:10,effect:'QUEIMADURA + QUEBRA DE ARMADURA'},
  {name:'BALA DO DRAGÃO',attr:'BALÍSTICA',damage:45,resource:'MUNIÇÃO',cost:3,effect:'IMPACTO PRECISO',extra:{cost:1,label:'+20 DE DANO',instant:20}},
  {name:'PASSO FANTASMA',attr:'ESTRATÉGIA',damage:0,resource:'TÁTICA',cost:3,effect:'INVISIBILIDADE + MIRA FRIA',setup:true,applySelf:[['INVISIBILIDADE',2]]},
  {name:'DRAGÃO VERMELHO',attr:'ESTRATÉGIA',damage:35,resource:'TÁTICA',cost:3,effect:'MARCAÇÃO',extra:{cost:1,label:'MARCAÇÃO: PRÓXIMO GOLPE +20',onWinSelf:[['MARCAÇÃO',1]]}},
  {name:'ANTI BLINDAGEM',attr:'BALÍSTICA',damage:20,resource:'MUNIÇÃO',cost:1,effect:'QUEBRA DE ARMADURA'},
  {name:'DEAD SHOT',attr:'BALÍSTICA',damage:130,resource:'MUNIÇÃO',cost:5,instant:20,effect:'ANTIFUGA + QUEBRA DE ARMADURA + SANGRAMENTO',antiFuga:true,limit:1},
  {name:'PONTO CEGO',attr:'ESTRATÉGIA',damage:30,resource:'TÁTICA',cost:2,effect:'FOGO CRUZADO',extra:{cost:1,label:'+3 NA ROLAGEM',rollBonus:3}}
 ],
 'JACK BLOOD':[
  {name:'APAGÃO',attr:'ESTRATÉGIA',damage:25,resource:'TÁTICA',cost:3,effect:'ESCURIDÃO',applyTarget:[['ESCURIDÃO',1]]},
  {name:'JOGO DO ASSASSINO',attr:'ESTRATÉGIA',damage:0,resource:'TÁTICA',cost:1,effect:'ARMADILHA: +3 NA PRÓXIMA RESOLUÇÃO',setup:true,applySelf:[['ARMADILHA',1]]},
  {name:'SEM SAÍDA',attr:'FORÇA',damage:35,resource:'LETALIDADE',cost:2,effect:'ATORDOAMENTO',applyTarget:[['ATORDOAMENTO',1]]},
  {name:'SENTENÇA VERMELHA',attr:'FORÇA',damage:40,resource:'LETALIDADE',cost:2,effect:'MARCADO PARA MORRER',onWinSelf:[['MARCADO',1]]},
  {name:'NINGUÉM SAI VIVO',attr:'FORÇA',damage:100,resource:'LETALIDADE',cost:4,instant:20,effect:'ANTIFUGA + SANGRAMENTO',antiFuga:true,limit:1},
  {name:'GOLPE DO CARRASCO',attr:'FORÇA',damage:20,resource:'LETALIDADE',cost:0,effect:'SEDE DE MATAR',gainLethalityExtra:1},
  {name:'SURPRESA!',attr:'FORÇA',damage:25,resource:'LETALIDADE',cost:1,effect:'SANGRAMENTO',instant:20}
 ],
 'MARSHALL B NICKO':[
  {name:'AGARRÃO PIRATA',attr:'FORÇA',damage:20,resource:'ESTAMINA',cost:3,effect:'PUXÃO PIRATA'},
  {name:'CANHÕES AMALDIÇOADOS',attr:'ARCANA',damage:30,resource:'MANA',cost:2,effect:'BOMBARDEIO MALDITO',extra:{cost:1,label:'APLICAR QUEIMADURA +10',instant:10}},
  {name:'CORTE DO CAOS',attr:'FORÇA',damage:25,resource:'ESTAMINA',cost:2,effect:'AGARRÃO PIRATA'},
  {name:'IMPERADOR DOS SETE MARES',attr:'FORÇA',damage:110,resource:'ESTAMINA',cost:4,effect:'SENTENÇA DO CAPITÃO',extra:{cost:2,label:'+30 E SANGRAMENTO +20',instant:50},limit:1},
  {name:'MALDIÇÃO DOS AFOGADOS',attr:'ARCANA',damage:25,resource:'MANA',cost:2,effect:'ASSOMBRAÇÃO',extra:{cost:1,label:'APLICAR MEDO -2',applyTarget:[['MEDO',1]]}},
  {name:'SERRANDO PRA CARALHO',attr:'FORÇA',damage:15,resource:'ESTAMINA',cost:1,effect:'AGARRÃO PIRATA'},
  {name:'KRAKEN NEGRO',attr:'ARCANA',damage:35,resource:'MANA',cost:4,effect:'DEVORADO',extra:{cost:2,label:'ATIVAR DEVORADO',applyTarget:[['DEVORADO',1]]}}
 ],
 'MATH SEVERUS':[
  {name:'O MAIOR PREDADOR',attr:'FORÇA',damage:110,resource:'ESTAMINA',cost:4,effect:'CAÇA PERFEITA',extra:{cost:2,label:'ANTIFUGA +20',instant:20,antiFuga:true},limit:1},
  {name:'LAÇO DO PREDADOR',attr:'FORÇA',damage:20,resource:'ESTAMINA',cost:2,effect:'DERRUBADA',extra:{cost:1,label:'APLICAR -3 NA PRÓXIMA ROLAGEM',applyTarget:[['ATORDOAMENTO',1]]}},
  {name:'LANÇA DO PREDADOR',attr:'FORÇA',damage:15,resource:'ESTAMINA',cost:1,effect:'NENHUM'},
  {name:'REDE DO PREDADOR',attr:'BALÍSTICA',damage:25,resource:'MUNIÇÃO',cost:2,effect:'CAPTURA',extra:{cost:1,label:'CAPTURAR: PERDE PRÓXIMA AÇÃO',applyTarget:[['CAPTURA',1]]}},
  {name:'BUMERANGUE DO CAÇADOR',attr:'FORÇA',damage:20,resource:'ESTAMINA',cost:2,effect:'RETORNO PRECISO',extra:{cost:1,label:'+20 DE DANO',instant:20}},
  {name:'FLECHA DO CAÇADOR',attr:'BALÍSTICA',damage:25,resource:'MUNIÇÃO',cost:1,effect:'SANGRAMENTO',extra:{cost:1,label:'APLICAR SANGRAMENTO +20',instant:20}},
  {name:'CAÇADA SELVAGEM',attr:'FORÇA',damage:25,resource:'ESTAMINA',cost:3,effect:'ATORDOAMENTO + SANGRAMENTO',extra:{cost:1,label:'ATORDOAMENTO + SANGRAMENTO',instant:20,applyTarget:[['ATORDOAMENTO',1]]}}
 ],
 'MUCA BLACKOUT':[
  {name:'RIFLE NANOTECH',attr:'BALÍSTICA',damage:120,resource:'MUNIÇÃO',cost:4,effect:'SANGRAMENTO + QUEIMADURA',instant:30,limit:1},
  {name:'ESSE TORNEIO EU VOU GANHAR',attr:'FORÇA',damage:25,resource:'ESTAMINA',cost:2,effect:'SANGRAMENTO',instant:20},
  {name:'BRUTALIDADE TÁTICA',attr:'FORÇA',damage:35,resource:'ESTAMINA',cost:3,effect:'IMPACTO',extra:{cost:1,label:'+20 DE DANO',instant:20}},
  {name:'DROPPER',attr:'ESTRATÉGIA',damage:40,resource:'TÁTICA',cost:3,effect:'DANO PERFURADOR'},
  {name:'GRANADA DE IMPACTO',attr:'ESTRATÉGIA',damage:10,resource:'TÁTICA',cost:1,effect:'ATORDOAMENTO',applyTarget:[['ATORDOAMENTO',1]]},
  {name:'RAJADA BLACKOUT',attr:'BALÍSTICA',damage:30,resource:'MUNIÇÃO',cost:2,effect:'SUPRESSÃO',applyTarget:[['SUPRESSÃO',1]]},
  {name:'TIRO CONTROLADO',attr:'BALÍSTICA',damage:25,resource:'MUNIÇÃO',cost:1,effect:'EXPLOSÃO DE BALAS',extra:{cost:1,label:'RESOLVER INDIVIDUALMENTE',applyTarget:[['EXPLOSÃO_DE_BALAS',1]]}}
 ],
 'O PATRIOTA':[
  {name:'BUMERANGUE',attr:'ESTRATÉGIA',damage:30,resource:'TÁTICA',cost:2,effect:'ANTIFUGA',extra:{cost:2,label:'ATIVAR ANTIFUGA',antiFuga:true}},
  {name:'ARREMESSO PATRIÓTICO',attr:'FORÇA',damage:20,resource:'ESTAMINA',cost:1,effect:'ATORDOAMENTO',extra:{cost:1,label:'APLICAR ATORDOAMENTO',applyTarget:[['ATORDOAMENTO',1]]}},
  {name:'ÚLTIMA LINHA DE DEFESA',attr:'ESTRATÉGIA',damage:0,resource:'TÁTICA',cost:1,effect:'RETALIAÇÃO',setup:true,applySelf:[['RETALIAÇÃO',1]],limit:2},
  {name:'ESTRELA CADENTE',attr:'FORÇA',damage:35,resource:'ESTAMINA',cost:2,effect:'QUEIMADURA',extra:{cost:1,label:'APLICAR QUEIMADURA +10',instant:10}},
  {name:'INVESTIDA DA LIBERDADE',attr:'FORÇA',damage:40,resource:'ESTAMINA',cost:2,effect:'QUEBRA DE GOLPE',extra:{cost:2,label:'QUEBRAR GOLPE DO OPONENTE',applyTarget:[['QUEBRA_DE_GOLPE',1]]}},
  {name:'COLISÃO DA LIBERDADE',attr:'FORÇA',damage:110,resource:'ESTAMINA',cost:3,effect:'IMPACTO DEVASTADOR',extra:{cost:2,label:'+30 DE DANO',instant:30},limit:1},
  {name:'SOCO DA LIBERDADE',attr:'FORÇA',damage:25,resource:'ESTAMINA',cost:1,effect:'NENHUM'}
 ]
};

const beats={'FORÇA':'ARCANA',ARCANA:'BALÍSTICA','BALÍSTICA':'ESTRATÉGIA','ESTRATÉGIA':'FORÇA'};
const EFFECTS={
 ATORDOAMENTO:{name:'ATORDOAMENTO',desc:'−3 na próxima rolagem de D12.'},
 MEDO:{name:'MEDO',desc:'−2 na próxima rolagem de D12.'},
 ESCURIDÃO:{name:'ESCURIDÃO',desc:'A próxima escolha de golpe é feita às cegas.'},
 INVISIBILIDADE:{name:'INVISIBILIDADE',desc:'Evita ataques enquanto houver cargas, exceto golpes com ANTI FUGA.'},
 ARMADILHA:{name:'ARMADILHA',desc:'+3 na próxima resolução de confronto.'},
 MARCAÇÃO:{name:'MARCAÇÃO',desc:'O próximo golpe que acertar recebe +20 de dano.'},
 MARCADO:{name:'MARCADO PARA MORRER',desc:'O próximo golpe de FORÇA que acertar recebe +20 de dano.'},
 RETALIAÇÃO:{name:'RETALIAÇÃO',desc:'Após receber dano, o próximo golpe de FORÇA recebe +30 de dano.'},
 CAPTURA:{name:'CAPTURA',desc:'Perde a próxima ação.'},
 SUPRESSÃO:{name:'SUPRESSÃO',desc:'Penalidade de −3 na próxima rolagem.'},
 QUEBRA_DE_GOLPE:{name:'QUEBRA DE GOLPE',desc:'Um golpe fica comprometido por 1 turno.'},
 DEVORADO:{name:'DEVORADO',desc:'Efeito especial do Kraken Negro.'},
 EXPLOSÃO_DE_BALAS:{name:'EXPLOSÃO DE BALAS',desc:'Efeito especial de múltiplos disparos.'}
};

function json(res,code,obj){res.writeHead(code,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(obj))}
function body(req){return new Promise((ok,no)=>{let s='';req.on('data',d=>{s+=d;if(s.length>1e6){no(new Error('big'));req.destroy()}});req.on('end',()=>{try{ok(s?JSON.parse(s):{})}catch{no(new Error('json'))}})})}
function hashPass(p,salt){return crypto.scryptSync(p,salt,64).toString('hex')}
function makeRecoveryCode(){return 'BW-'+crypto.randomBytes(3).toString('hex').toUpperCase()+'-'+crypto.randomBytes(3).toString('hex').toUpperCase()}
function setRecovery(id){const code=makeRecoveryCode(),salt=crypto.randomBytes(16).toString('hex'),hash=hashPass(code,salt);db.prepare('update users set recovery_hash=?,recovery_salt=? where id=?').run(hash,salt,id);return code}
function token(user){let payload=Buffer.from(JSON.stringify({id:user.id,username:user.username,exp:Date.now()+30*864e5})).toString('base64url');let sig=crypto.createHmac('sha256',SECRET).update(payload).digest('base64url');return payload+'.'+sig}
function auth(req){let t=(req.headers.authorization||'').replace(/^Bearer /,'');let [p,s]=t.split('.');if(!p||!s)return null;let sig=crypto.createHmac('sha256',SECRET).update(p).digest('base64url');let a=Buffer.from(sig),b=Buffer.from(s);if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;try{let x=JSON.parse(Buffer.from(p,'base64url').toString());if(x.exp<Date.now())return null;return db.prepare('select id,username,points,wins,losses,recovery_hash from users where id=?').get(x.id)||null}catch{return null}}
function rankName(points){if(points<=20)return'BARRO';if(points<=40)return'BRONZE';if(points<=60)return'PRATA';if(points<=90)return'OURO';if(points<=120)return'PLATINA';return'DIAMANTE'}
function safeUser(u){return {id:u.id,username:u.username,points:u.points||0,rank:rankName(u.points||0),wins:u.wins||0,losses:u.losses||0}}
function rankResult(wid,lid){let w=db.prepare('select * from users where id=?').get(wid),l=db.prepare('select * from users where id=?').get(lid),wp=(w.points||0)+10,lp=Math.max(0,(l.points||0)-5);db.exec('BEGIN');try{db.prepare('update users set points=?,wins=wins+1 where id=?').run(wp,wid);db.prepare('update users set points=?,losses=losses+1 where id=?').run(lp,lid);db.prepare('insert into matches(winner_id,loser_id,winner_before,loser_before,winner_after,loser_after) values(?,?,?,?,?,?)').run(wid,lid,w.points||0,l.points||0,wp,lp);db.exec('COMMIT')}catch(e){db.exec('ROLLBACK');throw e}return {winner:wp,loser:lp,winnerRank:rankName(wp),loserRank:rankName(lp)}}
function mkP(u,char){let c=CHARS[char];return {userId:u.id,username:u.username,points:u.points||0,rank:rankName(u.points||0),char,hp:c.hp,maxHp:c.hp,stats:{...c.stats},resources:{...c.resources},fuga:2,fugaClock:0,pick:null,effects:[],uses:{}}}
function movesFor(p){return M[p.char]}
function addEffect(p,id,charges=1){let meta=EFFECTS[id]||{name:id,desc:''},e=p.effects.find(x=>x.id===id);if(e)e.charges=Math.max(e.charges||1,charges);else p.effects.push({id,name:meta.name,desc:meta.desc,charges})}
function takeEffect(p,id){let i=p.effects.findIndex(x=>x.id===id);if(i<0)return null;let e=p.effects[i];e.charges=(e.charges||1)-1;if(e.charges<=0)p.effects.splice(i,1);return e}
function hasEffect(p,id){return p.effects.some(x=>x.id===id)}
function applyList(p,list){for(const x of list||[])addEffect(p,x[0],x[1]||1)}
function antiFuga(m,extra){return !!(m.antiFuga||(extra&&m.extra&&m.extra.antiFuga))}
function moveCost(m,extra){return m.cost+(extra&&m.extra?m.extra.cost:0)}
function canUse(p,slot,extra){let m=movesFor(p)[slot];if(!m)return false;if(m.limit&&((p.uses[slot]||0)>=m.limit))return false;return (p.resources[m.resource]||0)>=moveCost(m,extra)}
function spendMove(p,slot,extra){let m=movesFor(p)[slot],cost=moveCost(m,extra);p.resources[m.resource]-=cost;p.uses[slot]=(p.uses[slot]||0)+1}
function consumeRollPenalty(p){let mod=0;if(takeEffect(p,'ATORDOAMENTO'))mod-=3;if(takeEffect(p,'MEDO'))mod-=2;if(takeEffect(p,'SUPRESSÃO'))mod-=3;if(takeEffect(p,'ARMADILHA'))mod+=3;return mod}
function gainWin(p,jokempo,move,gains){if(p.resources.LETALIDADE!==undefined){let before=p.resources.LETALIDADE;p.resources.LETALIDADE=Math.min(6,p.resources.LETALIDADE+1+(move?.gainLethalityExtra||0));if(p.resources.LETALIDADE>before)gains.push({username:p.username,resource:'LETALIDADE',amount:p.resources.LETALIDADE-before})}if(jokempo&&p.resources['TÁTICA']!==undefined){let before=p.resources['TÁTICA'];p.resources['TÁTICA']=Math.min(6,p.resources['TÁTICA']+2);if(p.resources['TÁTICA']>before)gains.push({username:p.username,resource:'TÁTICA',amount:p.resources['TÁTICA']-before})}}
function tickFuga(p){p.fugaClock=(p.fugaClock||0)+1;if(p.fugaClock>=2){p.fuga=Math.min(2,p.fuga+1);p.fugaClock=0}}
function publicRoom(r,u){return {id:r.id,turn:r.turn,phase:r.phase,players:r.players.map(p=>({username:p.username,points:p.points,rank:p.rank,char:p.char,hp:p.hp,maxHp:p.maxHp,resources:p.resources,fuga:p.fuga,effects:p.effects})),lastEvent:r.lastEvent||null,finished:r.finished||null,locked:(r.players.find(p=>p.userId===u.id)?.pick!==null)}}
function finish(r,w,l){if(r.finished)return;r.phase='finished';let rr=rankResult(w.userId,l.userId);w.points=rr.winner;w.rank=rr.winnerRank;l.points=rr.loser;l.rank=rr.loserRank;r.finished={winner:w.username,points:rr,delta:{winner:10,loser:-5}};r.updated=Date.now()}
function damageFor(attacker,m,extra){let d=(attacker.stats[m.attr]||0)+m.damage+(m.instant||0)+(extra&&m.extra?(m.extra.instant||0):0);if(hasEffect(attacker,'MARCAÇÃO')){takeEffect(attacker,'MARCAÇÃO');d+=20}if(m.attr==='FORÇA'&&hasEffect(attacker,'MARCADO')){takeEffect(attacker,'MARCADO');d+=20}if(m.attr==='FORÇA'&&hasEffect(attacker,'RETALIAÇÃO')){takeEffect(attacker,'RETALIAÇÃO');d+=30}return d}
function applyOnHit(attacker,target,m,extra){applyList(target,m.applyTarget);if(extra&&m.extra)applyList(target,m.extra.applyTarget)}
function applySetup(p,m,extra){applyList(p,m.applySelf);if(extra&&m.extra)applyList(p,m.extra.applySelf)}
function hit(attacker,target,m,extra){if(hasEffect(target,'INVISIBILIDADE')&&!antiFuga(m,extra)){takeEffect(target,'INVISIBILIDADE');return {hit:false,damage:0,blocked:'INVISIBILIDADE'}}let d=damageFor(attacker,m,extra);target.hp-=d;applyOnHit(attacker,target,m,extra);if(hasEffect(target,'RETALIAÇÃO')){}return {hit:true,damage:d}}
function finishAfter(r){let a=r.players[0],b=r.players[1];if(a.hp<=0&&b.hp<=0){r.phase='finished';r.finished={draw:true}}else if(a.hp<=0)finish(r,b,a);else if(b.hp<=0)finish(r,a,b)}
function resolve(r){
 let a=r.players[0],b=r.players[1],pa=a.pick,pb=b.pick,gains=[];
 const makeReveal=(p,pick)=>pick.type==='fuga'?{username:p.username,char:p.char,type:'fuga'}:{username:p.username,char:p.char,type:'move',slot:pick.slot,move:movesFor(p)[pick.slot],extra:!!pick.extra};
 let ea=makeReveal(a,pa),eb=makeReveal(b,pb),event={type:'reveal',id:crypto.randomUUID(),a:ea,b:eb,winner:null,gains,fugaBy:[],antiFugaHits:[]};
 // both flee
 if(pa.type==='fuga'&&pb.type==='fuga'){
  event.fugaBy=[a.username,b.username];event.resolution='AMBOS USARAM FUGA';
 } else if(pa.type==='fuga'||pb.type==='fuga'){
  let runner=pa.type==='fuga'?a:b,attacker=pa.type==='fuga'?b:a,atkPick=pa.type==='fuga'?pb:pa,m=movesFor(attacker)[atkPick.slot];
  let roll=1+Math.floor(Math.random()*12),mod=consumeRollPenalty(attacker)+(atkPick.extra&&m.extra?(m.extra.rollBonus||0):0),total=roll+mod;
  let rev=pa.type==='fuga'?eb:ea;rev.roll=roll;rev.bonus=mod;rev.total=total;
  if(antiFuga(m,atkPick.extra)){
   let h=hit(attacker,runner,m,atkPick.extra);rev.damage=h.damage;event.antiFugaHits=[runner.username];event.winner=attacker.username;event.resolution='ANTI FUGA ACERTOU';gainWin(attacker,false,m,gains);
  }else{event.fugaBy=[runner.username];event.resolution=`${runner.username} ESCAPOU`}
 } else {
  let ma=movesFor(a)[pa.slot],mb=movesFor(b)[pb.slot];
  if(ma.setup||mb.setup){
   if(ma.setup)applySetup(a,ma,pa.extra);if(mb.setup)applySetup(b,mb,pb.extra);
   if(!ma.setup){let h=hit(a,b,ma,pa.extra);ea.roll=1+Math.floor(Math.random()*12);ea.total=ea.roll;ea.damage=h.damage;event.winner=h.hit?a.username:null}
   if(!mb.setup){let h=hit(b,a,mb,pb.extra);eb.roll=1+Math.floor(Math.random()*12);eb.total=eb.roll;eb.damage=h.damage;event.winner=h.hit?b.username:event.winner}
   event.resolution='SETUP RESOLVIDO';
  }else{
   let ra=1+Math.floor(Math.random()*12),rb=1+Math.floor(Math.random()*12),modA=consumeRollPenalty(a)+(pa.extra&&ma.extra?(ma.extra.rollBonus||0):0),modB=consumeRollPenalty(b)+(pb.extra&&mb.extra?(mb.extra.rollBonus||0):0),ba=beats[ma.attr]===mb.attr?5:0,bb=beats[mb.attr]===ma.attr?5:0,sa=ra+modA+ba,sb=rb+modB+bb;
   Object.assign(ea,{roll:ra,bonus:modA+ba,total:sa});Object.assign(eb,{roll:rb,bonus:modB+bb,total:sb});
   if(sa>sb){let h=hit(a,b,ma,pa.extra);ea.damage=h.damage;event.winner=a.username;gainWin(a,ba>0,ma,gains);if(pa.extra&&ma.extra)applyList(a,ma.extra.onWinSelf)}
   else if(sb>sa){let h=hit(b,a,mb,pb.extra);eb.damage=h.damage;event.winner=b.username;gainWin(b,bb>0,mb,gains);if(pb.extra&&mb.extra)applyList(b,mb.extra.onWinSelf)}
   else{let ha=hit(a,b,ma,pa.extra),hb=hit(b,a,mb,pb.extra);ea.damage=ha.damage;eb.damage=hb.damage;event.resolution='EMPATE — AMBOS ATACAM'}
  }
 }
 tickFuga(a);tickFuga(b);a.pick=b.pick=null;r.turn++;r.updated=Date.now();r.lastEvent=event;finishAfter(r)
}
function affordableChoices(p){return movesFor(p).map((m,i)=>({m,i,extra:false})).filter(x=>canUse(p,x.i,false))}
function freeAttack(r,actor,reason){let other=r.players.find(p=>p!==actor),choices=affordableChoices(other);if(!choices.length){r.lastEvent={type:'system',id:crypto.randomUUID(),text:`${other.username} não tem golpe pagável.`};tickFuga(actor);tickFuga(other);r.turn++;return}let c=choices[Math.floor(Math.random()*choices.length)];spendMove(other,c.i,false);let h=hit(other,actor,c.m,false);tickFuga(actor);tickFuga(other);r.lastEvent={type:'freeAttack',id:crypto.randomUUID(),from:other.username,to:actor.username,slot:c.i,move:c.m,damage:h.damage,reason};r.turn++;if(actor.hp<=0)finish(r,other,actor)}

async function api(req,res,url){
 let u=auth(req);
 if(url.pathname==='/api/register'&&req.method==='POST'){
  let b=await body(req),name=(b.username||'').trim(),pass=b.password||'';
  if(!/^[A-Za-z0-9_]{3,24}$/.test(name))return json(res,400,{error:'Nome: 3–24 caracteres, letras, números ou _.'});
  if(pass.length<6)return json(res,400,{error:'Senha precisa ter pelo menos 6 caracteres.'});
  if(db.prepare('select 1 from users where username=?').get(name))return json(res,409,{error:'Nome já existe.'});
  let salt=crypto.randomBytes(16).toString('hex'),h=hashPass(pass,salt),r=db.prepare('insert into users(username,passhash,salt,points) values(?,?,?,0)').run(name,h,salt),id=Number(r.lastInsertRowid),recoveryCode=setRecovery(id),nu=db.prepare('select * from users where id=?').get(id);
  return json(res,200,{token:token(nu),user:safeUser(nu),recoveryCode})
 }
 if(url.pathname==='/api/login'&&req.method==='POST'){
  let b=await body(req),x=db.prepare('select * from users where username=?').get((b.username||'').trim());
  if(!x||hashPass(b.password||'',x.salt)!==x.passhash)return json(res,401,{error:'Nome ou senha inválidos.'});
  let recoveryCode=null;if(!x.recovery_hash){recoveryCode=setRecovery(x.id);x=db.prepare('select * from users where id=?').get(x.id)}
  return json(res,200,{token:token(x),user:safeUser(x),recoveryCode})
 }
 if(url.pathname==='/api/reset-password'&&req.method==='POST'){
  let b=await body(req),name=(b.username||'').trim(),code=(b.recoveryCode||'').trim(),pass=b.newPassword||'',x=db.prepare('select * from users where username=?').get(name);
  if(pass.length<6)return json(res,400,{error:'A nova senha precisa ter pelo menos 6 caracteres.'});
  if(!x||!x.recovery_hash||!x.recovery_salt||hashPass(code,x.recovery_salt)!==x.recovery_hash)return json(res,400,{error:'Jogador ou código de recuperação inválido.'});
  let salt=crypto.randomBytes(16).toString('hex'),h=hashPass(pass,salt);db.prepare('update users set passhash=?,salt=? where id=?').run(h,salt,x.id);let recoveryCode=setRecovery(x.id);return json(res,200,{ok:true,recoveryCode})
 }
 if(url.pathname==='/api/rank')return json(res,200,db.prepare('select username,points,wins,losses from users order by points desc,wins desc,losses asc limit 100').all().map(x=>({...x,rank:rankName(x.points||0)})));
 if(!u)return json(res,401,{error:'unauthorized'});
 if(url.pathname==='/api/me')return json(res,200,safeUser(u));
 if(url.pathname==='/api/recovery-key'&&req.method==='POST'){let recoveryCode=setRecovery(u.id);return json(res,200,{recoveryCode})}
 if(url.pathname==='/api/queue'&&req.method==='POST'){
  let b=await body(req);if(!CHARS[b.char])return json(res,400,{error:'Personagem inválido'});let old=userRoom.get(u.id);if(old&&rooms.get(old)&&!rooms.get(old).finished)return json(res,200,{matched:true,room:old});let rival=waiting.find(x=>x.user.id!==u.id);if(!rival){if(!waiting.some(x=>x.user.id===u.id))waiting.push({user:u,char:b.char});return json(res,200,{queued:true})}waiting.splice(waiting.indexOf(rival),1);let id='m_'+crypto.randomBytes(6).toString('hex'),room={id,turn:1,phase:'choosing',players:[mkP(rival.user,rival.char),mkP(u,b.char)],lastEvent:null,updated:Date.now()};rooms.set(id,room);userRoom.set(u.id,id);userRoom.set(rival.user.id,id);return json(res,200,{matched:true,room:id})
 }
 if(url.pathname==='/api/queue/status'){let id=userRoom.get(u.id),r=id&&rooms.get(id);return json(res,200,r?{matched:true,room:id}:{queued:waiting.some(x=>x.user.id===u.id)})}
 if(url.pathname==='/api/state'){let id=url.searchParams.get('room')||userRoom.get(u.id),r=rooms.get(id);if(!r||!r.players.some(p=>p.userId===u.id))return json(res,404,{error:'Partida não encontrada'});return json(res,200,publicRoom(r,u))}
 if(url.pathname==='/api/pick'&&req.method==='POST'){
  let b=await body(req),r=rooms.get(userRoom.get(u.id));if(!r||r.phase!=='choosing')return json(res,400,{error:'Partida indisponível'});let p=r.players.find(x=>x.userId===u.id),slot=Number(b.slot),extra=!!b.extra;if(!Number.isInteger(slot)||slot<0||slot>6||p.pick!==null)return json(res,400,{error:'Escolha inválida'});let m=movesFor(p)[slot];if(extra&&!m.extra)return json(res,400,{error:'Este golpe não possui gasto extra.'});if(!canUse(p,slot,extra))return json(res,400,{error:`Sem ${m.resource} suficiente.`});spendMove(p,slot,extra);p.pick={type:'move',slot,extra};if(r.players.every(x=>x.pick!==null))resolve(r);return json(res,200,{ok:true})
 }
 if(url.pathname==='/api/recover'&&req.method==='POST'){
  let b=await body(req),r=rooms.get(userRoom.get(u.id));if(!r||r.phase!=='choosing')return json(res,400,{error:'Partida indisponível'});let p=r.players.find(x=>x.userId===u.id),map={RECARREGAR:['MUNIÇÃO',6],MEDITAR:['MANA',4],'FÔLEGO':['ESTAMINA',3]},v=map[b.kind];if(!v||p.resources[v[0]]===undefined)return json(res,400,{error:'Ação indisponível'});if(p.pick!==null)return json(res,400,{error:'Você já escolheu a ação.'});if(p.resources[v[0]]>=6)return json(res,400,{error:`${v[0]} já está 6/6`});p.resources[v[0]]=Math.min(6,p.resources[v[0]]+v[1]);freeAttack(r,p,b.kind);r.updated=Date.now();return json(res,200,{ok:true})
 }
 if(url.pathname==='/api/fuga'&&req.method==='POST'){
  let r=rooms.get(userRoom.get(u.id));if(!r||r.phase!=='choosing')return json(res,400,{error:'Partida indisponível'});let p=r.players.find(x=>x.userId===u.id);if(p.pick!==null)return json(res,400,{error:'Você já escolheu a ação.'});if(p.fuga<=0)return json(res,400,{error:'FUGA sem cargas'});p.fuga--;p.pick={type:'fuga'};if(r.players.every(x=>x.pick!==null))resolve(r);r.updated=Date.now();return json(res,200,{ok:true})
 }
 return json(res,404,{error:'not found'})
}

function staticFile(req,res,url){let raw=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname),file=path.normalize(path.join(ROOT,raw));if(!file.startsWith(ROOT))return res.end('forbidden');fs.stat(file,(e,st)=>{if(e||!st.isFile()){res.writeHead(404);return res.end('404')}let ext=path.extname(file).toLowerCase(),ct={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.wav':'audio/wav','.mp3':'audio/mpeg'}[ext]||'application/octet-stream';res.writeHead(200,{'content-type':ct,'cache-control':['.png','.jpg','.jpeg','.wav','.mp3'].includes(ext)?'public,max-age=604800':'no-cache'});fs.createReadStream(file).pipe(res)})}
const server=http.createServer(async(req,res)=>{let url=new URL(req.url,'http://localhost');try{if(url.pathname.startsWith('/api/'))return await api(req,res,url);staticFile(req,res,url)}catch(e){console.error(e);json(res,500,{error:'Erro interno'})}});
server.listen(PORT,()=>console.log('BATTLEWORLD ONLINE',PORT));
