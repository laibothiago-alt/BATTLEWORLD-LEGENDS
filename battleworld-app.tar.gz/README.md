# BATTLEWORLD V2.1 — defesa individual no FFA

Atualização V2.0:
- exige login ou criação de conta ao abrir o jogo; a sessão não reutiliza mais automaticamente a conta Hitoshi salva no aparelho;
- o perfil exibido no menu usa o nome, patente, pontos e vitórias/derrotas da conta conectada;
- adiciona Felphs Silverhand e Leandro Smoker ao elenco, totalizando 6 personagens do pacote atual;
- substitui os cards dos personagens e golpes pelos cards do pacote novo;
- corrige atributos, recursos, custos e efeitos conforme os cards, incluindo as regras de Muca Blackout;
- adiciona o atributo EXECUÇÃO como atributo neutro no Jokempô;
- mostra claramente o bônus `+5 JOKEMPÔ` na resolução de confrontos;
- no modo CLÁSSICO, revela o golpe atacante antes da escolha de contra-ataque;
- no FFA online e offline, cada jogador atacado recebe um aviso e escolhe um novo golpe defensivo para aquele confronto;
- impede que um único golpe escolhido seja reutilizado automaticamente contra todos os atacantes no FFA;
- adiciona ícones oficiais de efeitos e passivas;
- passivas ativadas aparecem no centro, seguem para o HUD e, quando consumidas, ficam em cinza com aparência quebrada;
- preserva as animações de cards, D12, confronto, impacto, dano e efeitos já existentes.

## Executar

Requer Node.js 22 ou superior.

```bash
npm start
```

Abra `http://localhost:3000`.
