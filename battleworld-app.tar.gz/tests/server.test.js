const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const fs=require('node:fs');
const path=require('node:path');

const port=33117;
const db=path.join('/tmp',`battleworld-test-${process.pid}.sqlite`);
const server=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,PORT:String(port),DB_PATH:db,JWT_SECRET:'test-secret'},stdio:'ignore'});
const base=`http://127.0.0.1:${port}`;
const pause=ms=>new Promise(r=>setTimeout(r,ms));

async function request(url,method='GET',data,token){
 const res=await fetch(base+url,{method,headers:{'content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},body:data?JSON.stringify(data):undefined});
 const body=await res.json();
 if(!res.ok)throw new Error(body.error||String(res.status));
 return body;
}

async function ready(){for(let i=0;i<40;i++){try{await fetch(base+'/');return}catch{await pause(50)}}throw new Error('Servidor não iniciou');}

(async()=>{
 try{
  await ready();
  const stamp=Date.now().toString(36);
  const users=[];
  for(const n of ['A','B','C'])users.push(await request('/api/register','POST',{username:`T${n}_${stamp}`,password:'123456'}));
  const chars=['HITOSHI ARAMAKI','MATH SEVERUS','MUCA BLACKOUT'];
  let matched;
  for(let i=0;i<3;i++)matched=await request('/api/queue','POST',{mode:'ffa',ffaSize:3,char:chars[i]},users[i].token);
  assert.equal(matched.matched,true);
  const states=[];
  for(const u of users)states.push(await request('/api/state?room='+matched.room,'GET',null,u.token));
  const ids=states[0].players.map(x=>x.id);
  await request('/api/pick','POST',{slot:0,targetId:ids[1]},users[0].token);
  await request('/api/pick','POST',{slot:5,targetId:ids[2]},users[1].token);
  await request('/api/pick','POST',{slot:2,targetId:ids[0]},users[2].token);
  let s=await request('/api/state?room='+matched.room,'GET',null,users[1].token);
  assert.equal(s.phase,'ffa-defense');
  assert.equal(String(s.ffaDefense.targetId),String(ids[1]));
  assert.match(s.ffaDefense.move,/CORTE DA SERPENTE/);
  await request('/api/pick','POST',{slot:2},users[1].token);
  s=await request('/api/state?room='+matched.room,'GET',null,users[2].token);
  assert.equal(String(s.ffaDefense.targetId),String(ids[2]));
  await request('/api/pick','POST',{slot:5},users[2].token);
  s=await request('/api/state?room='+matched.room,'GET',null,users[0].token);
  assert.equal(String(s.ffaDefense.targetId),String(ids[0]));
  await request('/api/pick','POST',{slot:1},users[0].token);
  s=await request('/api/state?room='+matched.room,'GET',null,users[0].token);
  assert.equal(s.phase,'choosing');
  assert.equal(s.turn,2);
  console.log('BATTLEWORLD server FFA: OK');
 }finally{
  server.kill('SIGTERM');
  for(const suffix of ['', '-shm', '-wal'])try{fs.rmSync(db+suffix)}catch{}
 }
})().catch(e=>{console.error(e);process.exitCode=1});
