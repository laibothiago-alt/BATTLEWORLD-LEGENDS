const assert=require('node:assert/strict');
const BW=require('../public/engine.js');

function room(players,mode='ffa'){return{mode,turn:1,players,freeActions:[],ffaQueue:[],ffaRoundActive:false,lastEvent:null};}
function p(id,char){return BW.makePlayer(id,id,char);}

// No FFA: cada ataque recebido exige uma escolha defensiva nova.
{
 const a=p('A','HITOSHI ARAMAKI'),b=p('B','MATH SEVERUS'),c=p('C','MUCA BLACKOUT'),r=room([a,b,c]);
 c.resources.MUNIÇÃO=0;
 BW.commitAction(r,a,{type:'move',slot:0,targetId:b.id});
 BW.commitAction(r,b,{type:'move',slot:5,targetId:c.id});
 BW.commitAction(r,c,{type:'recover',kind:'RECARREGAR'});
 const staminaBefore=b.resources.ESTAMINA;
 const start=BW.beginFfaRound(r);
 assert.equal(start.pending.targetId,b.id);
 assert.equal(start.pending.move,'CORTE DA SERPENTE');
 let out=BW.commitFfaDefense(r,b,{type:'move',slot:2,extra:false});
 assert.equal(out.event.combats[0].bMove,'LANÇA DO PREDADOR');
 assert.equal(b.resources.ESTAMINA,staminaBefore-1,'a defesa deve pagar seu próprio golpe');
 assert.equal(out.pending.targetId,c.id);
 assert.equal(out.pending.move,'FLECHA DO CAÇADOR','o ataque ofensivo original deve continuar separado da defesa');
 out=BW.commitFfaDefense(r,c,{type:'move',slot:2,extra:false});
 assert.equal(out.finished,true);
 assert.equal(r.turn,2);
 assert.equal(r.ffaRoundActive,false);
}

// Jokempô acrescenta +5 ao placar do confronto.
{
 const a=p('A','HITOSHI ARAMAKI'),b=p('B','MATH SEVERUS'),c=p('C','MUCA BLACKOUT'),r=room([a,b,c]);
 b.resources.MUNIÇÃO=0;c.resources.MUNIÇÃO=0;
 BW.commitAction(r,a,{type:'move',slot:3,targetId:b.id}); // ESTRATÉGIA vence FORÇA
 BW.commitAction(r,b,{type:'recover',kind:'RECARREGAR'});
 BW.commitAction(r,c,{type:'recover',kind:'RECARREGAR'});
 BW.beginFfaRound(r);
 const out=BW.commitFfaDefense(r,b,{type:'move',slot:2});
 const fight=out.event.combats[0];
 assert.equal(fight.aJokempo,5);
 assert.equal(fight.aScore,fight.aRoll+fight.aRollMod+5);
}

// Muca: somente os efeitos descritos nos cards revisados.
{
 const m=BW.M['MUCA BLACKOUT'];
 assert.deepEqual(m[2].extra.instantEffects,[['SANGRAMENTO',20]]);
 assert.equal(m[4].autoInstant,15);
 assert.deepEqual(m[4].instantEffects,[['ENVENENAMENTO',15]]);
 assert.equal(m[6].autoInstant,20);
 assert.deepEqual(m[6].instantEffects,[['SANGRAMENTO',20]]);
 assert.equal(m[1].cost,3);
}

console.log('BATTLEWORLD rules: OK');
