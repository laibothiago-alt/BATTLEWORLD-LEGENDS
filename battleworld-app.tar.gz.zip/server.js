const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {DatabaseSync}=require('node:sqlite');
const BW=require('./public/engine.js');

const PORT=process.env.PORT||3000;
const SECRET=process.env.JWT_SECRET||'battleworld-dev-secret-change-me';
const ROOT=path.join(__dirname,'public');
const db=new DatabaseSync(process.env.DB_PATH||path.join(__dirname,'battleworld.sqlite'));
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE COLLATE NOCASE,
 passhash TEXT NOT NULL,
 salt TEXT NOT NULL,
 rating INTEGER NOT NULL DEFAULT 1000,
 wins INTEGER NOT NULL DEFAULT 0,
 losses INTEGER NOT NULL DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS matches(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 winner_id INTEGER,
 loser_id INTEGER,
 winner_before INTEGER,
 loser_before INTEGER,
 winner_after INTEGER,
 loser_after INTEGER,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);`);
function ensureColumn(table,name,sql){try{db.prepare(`select ${name} from ${table} limit 1`).get()}catch{db.exec(`alter table ${table} add column ${name} ${sql}`)}}
ensureColumn('users','points','INTEGER NOT NULL DEFAULT 0');
ensureColumn('users','recovery_hash','TEXT');
ensureColumn('users','recovery_salt','TEXT');

const waiting1v1=[];
const waitingClassic=[];
const waitingFfa3=[];
const waitingFfa4=[];
const userRoom=new Map();
const rooms=new Map();

function json(res,code,obj){res.writeHead(code,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(obj))}
function body(req){return new Promise((ok,no)=>{let s='';req.on('data',d=>{s+=d;if(s.length>2e6){no(new Error('big'));req.destroy()}});req.on('end',()=>{try{ok(s?JSON.parse(s):{})}catch{no(new Error('json'))}})})}
function hashPass(p,salt){return crypto.scryptSync(p,salt,64).toString('hex')}
function makeRecoveryCode(){return 'BW-'+crypto.randomBytes(3).toString('hex').toUpperCase()+'-'+crypto.randomBytes(3).toString('hex').toUpperCase()}
function setRecovery(id){const code=makeRecoveryCode(),salt=crypto.randomBytes(16).toString('hex'),hash=hashPass(code,salt);db.prepare('update users set recovery_hash=?,recovery_salt=? where id=?').run(hash,salt,id);return code}
function token(user){let payload=Buffer.from(JSON.stringify({id:user.id,username:user.username,exp:Date.now()+30*864e5})).toString('base64url');let sig=crypto.createHmac('sha256',SECRET).update(payload).digest('base64url');return payload+'.'+sig}
function auth(req){let t=(req.headers.authorization||'').replace(/^Bearer /,'');let [p,s]=t.split('.');if(!p||!s)return null;let sig=crypto.createHmac('sha256',SECRET).update(p).digest('base64url');let a=Buffer.from(sig),b=Buffer.from(s);if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;try{let x=JSON.parse(Buffer.from(p,'base64url').toString());if(x.exp<Date.now())return null;return db.prepare('select id,username,points,wins,losses,recovery_hash from users where id=?').get(x.id)||null}catch{return null}}
function rankName(points){if(points<=20)return'BARRO';if(points<=40)return'BRONZE';if(points<=60)return'PRATA';if(points<=90)return'OURO';if(points<=120)return'PLATINA';return'DIAMANTE'}
function safeUser(u){return{id:u.id,username:u.username,points:u.points||0,rank:rankName(u.points||0),wins:u.wins||0,losses:u.losses||0}}
function rankResult(wid,lid){let w=db.prepare('select * from users where id=?').get(wid),l=db.prepare('select * from users where id=?').get(lid),wp=(w.points||0)+10,lp=Math.max(0,(l.points||0)-5);db.exec('BEGIN');try{db.prepare('update users set points=?,wins=wins+1 where id=?').run(wp,wid);db.prepare('update users set points=?,losses=losses+1 where id=?').run(lp,lid);db.prepare('insert into matches(winner_id,loser_id,winner_before,loser_before,winner_after,loser_after) values(?,?,?,?,?,?)').run(wid,lid,w.points||0,l.points||0,wp,lp);db.exec('COMMIT')}catch(e){db.exec('ROLLBACK');throw e}return{winner:wp,loser:lp,winnerRank:rankName(wp),loserRank:rankName(lp)}}
function mkP(u,char){return BW.makePlayer(u.id,u.username,char,u.points||0,rankName(u.points||0))}
function removeFromQueues(uid){for(const q of [waiting1v1,waitingClassic,waitingFfa3,waitingFfa4]){let i;while((i=q.findIndex(x=>x.user.id===uid))>=0)q.splice(i,1)}}
function newRoom(entries,mode){let id=(mode==='ffa'?'f_':mode==='classic'?'c_':'m_')+crypto.randomBytes(6).toString('hex'),players=entries.map(x=>mkP(x.user,x.char)),r={id,mode,ranked:mode==='1v1',turn:1,phase:'choosing',players,lastEvent:null,updated:Date.now(),freeActions:[],finished:null,ffaSize:mode==='ffa'?entries.length:null,classicAttackerId:mode==='classic'?players[0]?.id:null};rooms.set(id,r);for(const x of entries)userRoom.set(x.user.id,id);return r}
function publicPlayer(p){return{id:p.id,username:p.username,points:p.points,rank:p.rank,char:p.char,hp:p.hp,maxHp:p.maxHp,resources:p.resources,resistance:p.resistance||0,maxResistance:p.maxResistance||0,fuga:p.fuga,effects:p.effects,passive:p.passive,uses:p.uses,disabledUntil:p.disabledUntil,devouredUltimate:p.devouredUltimate,matchStats:p.matchStats||{damage:0,kos:0,lastMove:null,defeated:[]}}}
function classicAttackInfo(r,u){if(r.mode!=='classic')return null;let a=r.players.find(p=>String(p.id)===String(r.classicAttackerId));if(!a?.pick||String(a.id)===String(u.id))return null;let pk=a.pick;if(pk.type==='move'){let m=BW.movesFor(a)[pk.slot];return{fromId:a.id,from:a.username,char:a.char,slot:pk.slot,move:m?.name||'GOLPE',attr:m?.attr||''}}if(pk.type==='recover')return{fromId:a.id,from:a.username,char:a.char,action:pk.kind};if(pk.type==='fuga')return{fromId:a.id,from:a.username,char:a.char,action:'FUGA'};return{fromId:a.id,from:a.username,char:a.char,action:'AÇÃO'}}
function classicCanAct(r,p){if(r.mode!=='classic')return true;let a=r.players.find(x=>String(x.id)===String(r.classicAttackerId));if(!a)return true;if(!a.pick)return String(p.id)===String(a.id);return String(p.id)!==String(a.id)&&!p.pick}
function publicRoom(r,u){let me=r.players.find(p=>p.id===u.id),fa=r.freeActions?.[0]||null,classicLocked=r.mode==='classic'&&!classicCanAct(r,me);return{id:r.id,mode:r.mode,ranked:r.ranked,turn:r.turn,phase:r.phase,meId:me?.id,players:r.players.map(publicPlayer),lastEvent:r.lastEvent||null,finished:r.finished||null,ffaSize:r.ffaSize||null,classicAttackerId:r.classicAttackerId||null,classicAttack:classicAttackInfo(r,u),freeAction:fa?{kind:fa.kind,username:r.players.find(p=>String(p.id)===String(fa.actorId))?.username||null,actorId:fa.actorId,targetId:fa.targetId,reason:fa.reason}:null,locked:!!fa?String(fa.actorId)!==String(u.id):r.mode==='classic'?(classicLocked||!!me?.pick):!!me?.pick}}
function checkFinish(r){if(r.finished)return true;let living=BW.alive(r);if(r.mode==='1v1'||r.mode==='classic'){if(living.length===2)return false;if(living.length===0){r.phase='finished';r.finished={draw:true};return true}let w=living[0],l=r.players.find(p=>p.id!==w.id);r.phase='finished';if(r.mode==='1v1'){let rr=rankResult(w.id,l.id);w.points=rr.winner;w.rank=rr.winnerRank;l.points=rr.loser;l.rank=rr.loserRank;r.finished={winner:w.username,winnerId:w.id,winnerChar:w.char,stats:w.matchStats||{},points:rr,delta:{winner:10,loser:-5},rankedPlayers:[{id:w.id,username:w.username,beforePoints:rr.winner-10,afterPoints:rr.winner,beforeRank:rankName(rr.winner-10),afterRank:rr.winnerRank,delta:10},{id:l.id,username:l.username,beforePoints:rr.loser+5,afterPoints:rr.loser,beforeRank:rankName(rr.loser+5),afterRank:rr.loserRank,delta:-5}]};}else r.finished={winner:w.username,winnerId:w.id,winnerChar:w.char,stats:w.matchStats||{},classic:true};return true}else{if(living.length>1)return false;r.phase='finished';r.finished=living.length===1?{winner:living[0].username,winnerId:living[0].id,winnerChar:living[0].char,stats:living[0].matchStats||{},ffa:true}:{draw:true,ffa:true};return true}}
function maybeResolve(r){if(r.freeActions?.length)return;if(BW.allReady(r)){let oldAttacker=r.classicAttackerId;BW.resolveRound(r);let finished=checkFinish(r);if(r.mode==='classic'&&!finished){let next=r.players.find(p=>p.hp>0&&String(p.id)!==String(oldAttacker));if(next)r.classicAttackerId=next.id}}}
function getActiveRoom(u){let id=userRoom.get(u.id),r=id&&rooms.get(id);return r&&!r.finished?r:null}

async function api(req,res,url){
 let u=auth(req);
 if(url.pathname==='/api/register'&&req.method==='POST'){
  let b=await body(req),name=(b.username||'').trim(),pass=b.password||'';
  if(!/^[A-Za-z0-9_]{3,24}$/.test(name))return json(res,400,{error:'Nome: 3–24 caracteres, letras, números ou _.'});
  if(pass.length<6)return json(res,400,{error:'Senha precisa ter pelo menos 6 caracteres.'});
  if(db.prepare('select 1 from users where username=?').get(name))return json(res,409,{error:'Nome já existe.'});
  let salt=crypto.randomBytes(16).toString('hex'),h=hashPass(pass,salt),rr=db.prepare('insert into users(username,passhash,salt,points) values(?,?,?,0)').run(name,h,salt),id=Number(rr.lastInsertRowid),recoveryCode=setRecovery(id),nu=db.prepare('select * from users where id=?').get(id);
  return json(res,200,{token:token(nu),user:safeUser(nu),recoveryCode})
 }
 if(url.pathname==='/api/login'&&req.method==='POST'){
  let b=await body(req),x=db.prepare('select * from users where username=?').get((b.username||'').trim());
  if(!x||hashPass(b.password||'',x.salt)!==x.passhash)return json(res,401,{error:'Nome ou senha inválidos.'});
  let recoveryCode=null;if(!x.recovery_hash){recoveryCode=setRecovery(x.id);x=db.prepare('select * from users where id=?').get(x.id)}
  return json(res,200,{token:token(x),user:safeUser(x),recoveryCode})
 }
 if(url.pathname==='/api/reset-password'&&req.method==='POST'){
  let b=await body(req),name=(b.username||'').trim(),code=(b.recoveryCode||'').trim(),pass=b.newPassword||'',x=db.prepare('select * from users where username=?').get(name);
  if(pass.length<6)return json(res,400,{error:'A nova senha precisa ter pelo menos 6 caracteres.'});
  if(!x||!x.recovery_hash||!x.recovery_salt||hashPass(code,x.recovery_salt)!==x.recovery_hash)return json(res,400,{error:'Jogador ou código de recuperação inválido.'});
  let salt=crypto.randomBytes(16).toString('hex'),h=hashPass(pass,salt);db.prepare('update users set passhash=?,salt=? where id=?').run(h,salt,x.id);let recoveryCode=setRecovery(x.id);return json(res,200,{ok:true,recoveryCode})
 }
 if(url.pathname==='/api/rank')return json(res,200,db.prepare('select username,points,wins,losses from users order by points desc,wins desc,losses asc limit 100').all().map(x=>({...x,rank:rankName(x.points||0)})));
 if(!u)return json(res,401,{error:'unauthorized'});
 if(url.pathname==='/api/me')return json(res,200,safeUser(u));
 if(url.pathname==='/api/recovery-key'&&req.method==='POST'){let recoveryCode=setRecovery(u.id);return json(res,200,{recoveryCode})}
 if(url.pathname==='/api/queue/cancel'&&req.method==='POST'){removeFromQueues(u.id);return json(res,200,{ok:true})}
 if(url.pathname==='/api/queue'&&req.method==='POST'){
  let b=await body(req),mode=b.mode==='ffa'?'ffa':b.mode==='classic'?'classic':'1v1',ffaSize=Number(b.ffaSize)===4?4:3;if(!BW.CHARS[b.char])return json(res,400,{error:'Personagem inválido'});
  let old=getActiveRoom(u);if(old)return json(res,200,{matched:true,room:old.id,mode:old.mode,ffaSize:old.ffaSize||null});removeFromQueues(u.id);
  let q=mode==='ffa'?(ffaSize===4?waitingFfa4:waitingFfa3):mode==='classic'?waitingClassic:waiting1v1,need=mode==='ffa'?ffaSize:2;q.push({user:u,char:b.char});
  if(q.length<need)return json(res,200,{queued:true,mode,waiting:q.length,need,ffaSize:mode==='ffa'?ffaSize:null});
  let entries=q.splice(0,need),r=newRoom(entries,mode);return json(res,200,{matched:true,room:r.id,mode,ffaSize:r.ffaSize||null})
 }
 if(url.pathname==='/api/queue/status'){
  let id=userRoom.get(u.id),r=id&&rooms.get(id);if(r&&!r.finished)return json(res,200,{matched:true,room:id,mode:r.mode,ffaSize:r.ffaSize||null});
  let i1=waiting1v1.findIndex(x=>x.user.id===u.id),ic=waitingClassic.findIndex(x=>x.user.id===u.id),i3=waitingFfa3.findIndex(x=>x.user.id===u.id),i4=waitingFfa4.findIndex(x=>x.user.id===u.id);if(i1>=0)return json(res,200,{queued:true,mode:'1v1',waiting:waiting1v1.length,need:2});if(ic>=0)return json(res,200,{queued:true,mode:'classic',waiting:waitingClassic.length,need:2});if(i3>=0)return json(res,200,{queued:true,mode:'ffa',waiting:waitingFfa3.length,need:3,ffaSize:3});if(i4>=0)return json(res,200,{queued:true,mode:'ffa',waiting:waitingFfa4.length,need:4,ffaSize:4});return json(res,200,{queued:false})
 }
 if(url.pathname==='/api/state'){
  let id=url.searchParams.get('room')||userRoom.get(u.id),r=rooms.get(id);if(!r||!r.players.some(p=>p.id===u.id))return json(res,404,{error:'Partida não encontrada'});return json(res,200,publicRoom(r,u))
 }
 if(url.pathname==='/api/pick'&&req.method==='POST'){
  let b=await body(req),r=getActiveRoom(u);if(!r||r.phase!=='choosing')return json(res,400,{error:'Partida indisponível'});let p=r.players.find(x=>x.id===u.id);if(r.mode==='classic'&&!classicCanAct(r,p)&&!r.freeActions?.length)return json(res,400,{error:'Aguarde o golpe do adversário.'});try{if(r.freeActions?.length){BW.executeFreeAction(r,p,{slot:b.slot,extra:!!b.extra,targetId:b.targetId});checkFinish(r)}else{BW.commitAction(r,p,{type:'move',slot:b.slot,extra:!!b.extra,targetId:b.targetId,extraTargets:b.extraTargets||[]});maybeResolve(r)}return json(res,200,{ok:true})}catch(e){return json(res,400,{error:e.message})}
 }
 if(url.pathname==='/api/recover'&&req.method==='POST'){
  let b=await body(req),r=getActiveRoom(u);if(!r||r.phase!=='choosing')return json(res,400,{error:'Partida indisponível'});if(r.freeActions?.length)return json(res,400,{error:'Resolva primeiro a ação gratuita.'});let p=r.players.find(x=>x.id===u.id);if(r.mode==='classic'&&!classicCanAct(r,p))return json(res,400,{error:'Aguarde o golpe do adversário.'});try{BW.commitAction(r,p,{type:'recover',kind:b.kind});maybeResolve(r);return json(res,200,{ok:true})}catch(e){return json(res,400,{error:e.message})}
 }
 if(url.pathname==='/api/fuga'&&req.method==='POST'){
  let r=getActiveRoom(u);if(!r||r.phase!=='choosing')return json(res,400,{error:'Partida indisponível'});if(r.freeActions?.length)return json(res,400,{error:'Resolva primeiro a ação gratuita.'});let p=r.players.find(x=>x.id===u.id);if(r.mode==='classic'&&!classicCanAct(r,p))return json(res,400,{error:'Aguarde o golpe do adversário.'});try{BW.commitAction(r,p,{type:'fuga'});maybeResolve(r);return json(res,200,{ok:true})}catch(e){return json(res,400,{error:e.message})}
 }
 if(url.pathname==='/api/passive'&&req.method==='POST'){
  let b=await body(req),r=getActiveRoom(u);if(!r||r.phase!=='choosing')return json(res,400,{error:'Partida indisponível'});if(r.freeActions?.length)return json(res,400,{error:'Resolva primeiro a ação gratuita.'});let p=r.players.find(x=>x.id===u.id);try{let text=BW.activatePassive(r,p,b.targetId);r.lastEvent={type:'system',id:crypto.randomUUID(),text:`✦ ${p.username}: ${text}`};r.updated=Date.now();return json(res,200,{ok:true,text})}catch(e){return json(res,400,{error:e.message})}
 }
 if(url.pathname==='/api/voice'&&req.method==='POST'){let b=await body(req),r=getActiveRoom(u);if(!r)return json(res,400,{error:'Partida indisponível'});let box=voiceBox(r.id);box.push({id:crypto.randomUUID(),from:u.id,to:b.to,type:b.type,data:b.data,at:Date.now()});if(box.length>200)box.splice(0,box.length-200);return json(res,200,{ok:true})}
 if(url.pathname==='/api/voice'&&req.method==='GET'){let r=getActiveRoom(u);if(!r)return json(res,200,[]);let since=Number(url.searchParams.get('since')||0),items=voiceBox(r.id).filter(x=>x.at>since&&String(x.to)===String(u.id));return json(res,200,items)}
 return json(res,404,{error:'not found'})
}
function staticFile(req,res,url){let raw=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname),file=path.normalize(path.join(ROOT,raw));if(!file.startsWith(ROOT))return res.end('forbidden');fs.stat(file,(e,st)=>{if(e||!st.isFile()){res.writeHead(404);return res.end('404')}let ext=path.extname(file).toLowerCase(),ct={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.wav':'audio/wav','.mp3':'audio/mpeg'}[ext]||'application/octet-stream';res.writeHead(200,{'content-type':ct,'cache-control':['.png','.jpg','.jpeg','.wav','.mp3'].includes(ext)?'public,max-age=604800':'no-cache'});fs.createReadStream(file).pipe(res)})}
const voiceBoxes=new Map();
function voiceBox(room){if(!voiceBoxes.has(room))voiceBoxes.set(room,[]);return voiceBoxes.get(room)}
const server=http.createServer(async(req,res)=>{let url=new URL(req.url,'http://localhost');try{if(url.pathname.startsWith('/api/'))return await api(req,res,url);staticFile(req,res,url)}catch(e){console.error(e);json(res,500,{error:'Erro interno'})}});
server.listen(PORT,()=>console.log('BATTLEWORLD ONLINE',PORT));
