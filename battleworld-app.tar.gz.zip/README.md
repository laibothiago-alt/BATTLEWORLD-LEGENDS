# BATTLEWORLD V1.4 — animações restauradas

Base V1.3 preservada (menus ONLINE/OFFLINE, Ranqueado/Clássico/FFA, FFA 3P/4P e recarga da CPU).

Correção V1.4:
- restaura/força a animação de entrada dos cards de confronto;
- restaura a rolagem visual do D12;
- mantém transição de resultado, impacto, shake e dano;
- restaura movimento visual dos cards e pulsos de recursos;
- adiciona cache-busting em CSS/JS para evitar que o celular carregue uma mistura de arquivos antigos e novos.
