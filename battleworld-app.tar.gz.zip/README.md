# BATTLEWORLD V1.8 — login e efeitos corrigidos

Correção V1.8:
- o botão ONLINE não entra mais silenciosamente na conta salva;
- quando há sessão salva, permite continuar, trocar de conta ou criar uma nova;
- a tela de login agora alterna entre ENTRAR e CRIAR CONTA;
- recuperação de senha também está acessível pela tela de login.

Correção V1.7:
- efeitos geram eventos próprios, sem depender da leitura do texto do registro;
- cada efeito aparece rapidamente no centro da tela e, quando persistente, segue para o HUD do personagem afetado;
- ESCURIDÃO permanece ativa até a próxima escolha de golpe feita às cegas;
- CAPTURA permanece visível no HUD até consumir a ação perdida;
- Sangramento, Queimadura e Envenenamento exibem ícone e dano instantâneo;
- golpes com dois efeitos exibem ambos em sequência.

## Histórico

### V1.4 — animações restauradas

Base V1.3 preservada (menus ONLINE/OFFLINE, Ranqueado/Clássico/FFA, FFA 3P/4P e recarga da CPU).

Correção V1.4:
- restaura/força a animação de entrada dos cards de confronto;
- restaura a rolagem visual do D12;
- mantém transição de resultado, impacto, shake e dano;
- restaura movimento visual dos cards e pulsos de recursos;
- adiciona cache-busting em CSS/JS para evitar que o celular carregue uma mistura de arquivos antigos e novos.
